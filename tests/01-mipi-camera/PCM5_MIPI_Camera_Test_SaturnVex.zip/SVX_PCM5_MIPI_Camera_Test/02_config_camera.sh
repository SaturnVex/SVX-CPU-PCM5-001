#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 02_config_camera.sh - select the MIPI port used by the IMX219 camera.
#
# Usage : sudo bash 02_config_camera.sh mipi1   # camera on MIPI1 -> dtoverlay=imx219,cam0
#         sudo bash 02_config_camera.sh mipi2   # camera on MIPI2 -> dtoverlay=imx219 (fit H4 jumpers)
#         sudo bash 02_config_camera.sh both    # two cameras
#         sudo bash 02_config_camera.sh show    # print current settings
#         sudo bash 02_config_camera.sh remove  # remove camera settings
#         then: sudo reboot
#
# Port mapping on SVX-CPU-PCM5-001:
#   MIPI1 = DPHY0, I2C SCL0/SDA0, power enable CAM_GPIO0      -> cam0
#   MIPI2 = DPHY1, I2C SCL1/SDA1 = ID_SC/ID_SD via jumper H4,
#           power enable pulled up to 3.3 V                   -> cam1 (default port)
# The script is idempotent: it always removes its previous block first.
set -euo pipefail

MODE="${1:-}"
CFG=/boot/firmware/config.txt
[ -f "$CFG" ] || CFG=/boot/config.txt
BEGIN="# >>> SVX camera (02_config_camera.sh) >>>"
END="# <<< SVX camera (02_config_camera.sh) <<<"

show() {
    echo "----- $CFG (camera related lines) -----"
    grep -nE '^\[|camera_auto_detect|imx219|i2c_arm|SVX camera' "$CFG" || true
    echo "---------------------------------------"
}

case "$MODE" in
    mipi1)  OVERLAYS=("dtoverlay=imx219,cam0") ;;
    mipi2)  OVERLAYS=("dtoverlay=imx219") ;;
    both)   OVERLAYS=("dtoverlay=imx219,cam0" "dtoverlay=imx219") ;;
    remove) OVERLAYS=() ;;
    show)   show; exit 0 ;;
    *) echo "Argument: mipi1 | mipi2 | both | show | remove"; exit 1 ;;
esac

if [ "$(id -u)" -ne 0 ]; then
    echo "Run with sudo:  sudo bash $0 $MODE"; exit 1
fi

# Keep the original file once, plus a time-stamped backup on every run
[ -f "${CFG}.orig" ] || cp "$CFG" "${CFG}.orig"
cp "$CFG" "${CFG}.$(date +%Y%m%d-%H%M%S).bak"

sed -i 's/\r$//' "$CFG"                                     # strip Windows line endings
sed -i '/^# >>> SVX camera/,/^# <<< SVX camera/d' "$CFG"    # remove previous block
sed -i '/^# >>> camera-imx219/,/^# <<< camera-imx219/d' "$CFG" # remove legacy engineering block
sed -i -E '/^[[:space:]]*dtoverlay=imx219/d' "$CFG"         # remove stray imx219 lines

# Third-party (non Raspberry Pi) camera: disable auto-detect, declare overlay explicitly
sed -i -E 's/^[[:space:]]*camera_auto_detect=.*/camera_auto_detect=0/' "$CFG"
grep -q '^camera_auto_detect=0' "$CFG" || sed -i '1i camera_auto_detect=0' "$CFG"


sed -i -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$CFG"            # trim trailing blank lines
if [ "${#OVERLAYS[@]}" -gt 0 ]; then
    {
        echo ""
        echo "$BEGIN"
        echo "[all]"
        for o in "${OVERLAYS[@]}"; do echo "$o"; done
        echo "$END"
    } >> "$CFG"
fi

show
case "$MODE" in
    mipi1)  echo "Camera on MIPI1 (cam0). H4 jumpers not required." ;;
    mipi2)  echo "Camera on MIPI2 (cam1). FIT BOTH H4 JUMPERS: 1-2 and 3-4." ;;
    both)   echo "Two cameras: MIPI1=cam0, MIPI2=cam1. Fit both H4 jumpers." ;;
    remove) echo "Camera settings removed." ;;
esac
echo "Original file kept at: ${CFG}.orig"
echo "Now run:  sudo reboot"
