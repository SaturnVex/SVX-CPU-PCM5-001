#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 03_diag.sh - collect camera diagnostics into diag.txt (same folder).
# Usage : sudo bash 03_diag.sh
CFG=/boot/firmware/config.txt; [ -f "$CFG" ] || CFG=/boot/config.txt
OUT="$(cd "$(dirname "$0")" && pwd)/diag.txt"

sec() { echo; echo "==================== $* ===================="; }

{
sec "Date / model / OS"
date
tr -d '\0' < /proc/device-tree/model; echo
uname -a
grep -E 'PRETTY_NAME' /etc/os-release
rpicam-hello --version 2>&1 | head -n 3

sec "config.txt (active lines)"
grep -vE '^[[:space:]]*(#|$)' "$CFG"

sec "Firmware log: device tree and overlays"
vclog -m 2>/dev/null | grep -iE 'dtb|overlay|imx219|error|fail' | tail -n 40

sec "imx219 nodes in live device tree"
NODES=$(find /proc/device-tree -iname 'imx219*' 2>/dev/null)
if [ -z "$NODES" ]; then
    echo "NO imx219 node -> overlay not loaded"
else
    for n in $NODES; do echo "$n  status=$(tr -d '\0' < "$n/status" 2>/dev/null || echo okay)"; done
fi

sec "Kernel log: imx219 / cfe / csi"
dmesg | grep -iE 'imx219|rp1-cfe|cfe|csi' | tail -n 60

sec "Kernel modules"
lsmod | grep -iE 'imx219|rp1_cfe|pisp'

sec "Camera regulators"
for r in /sys/class/regulator/regulator.*; do
    name=$(cat "$r/name" 2>/dev/null)
    case "$name" in *cam*|*CAM*) echo "$name  state=$(cat "$r/state" 2>/dev/null)";; esac
done

sec "GPIO0/1 (ID_SD/ID_SC, MIPI2 I2C via H4)"
pinctrl get 0-1 2>/dev/null

sec "I2C buses and IMX219 probe at 0x10 (UU = bound by driver, 10 = present, -- = absent)"
i2cdetect -l
for b in $(i2cdetect -l | awk '{print $1}' | sed 's/i2c-//'); do
    line=$(i2cdetect -y "$b" 0x10 0x10 2>/dev/null | grep '^10:')
    echo "i2c-$b : ${line:-scan error}"
done

sec "rpicam-hello --list-cameras"
rpicam-hello --list-cameras 2>&1 | tail -n 20
} > "$OUT" 2>&1

cat "$OUT"
echo
echo "=> Saved: $OUT"
