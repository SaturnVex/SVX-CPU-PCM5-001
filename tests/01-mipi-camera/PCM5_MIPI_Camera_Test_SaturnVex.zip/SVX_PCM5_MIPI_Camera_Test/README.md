# MIPI Camera (MIPI1 / MIPI2) Test

**Package:** `SVX_PCM5_MIPI_Camera_Test` · **Board:** `SVX-CPU-PCM5-001` · **Module:** Raspberry Pi CM5 (tested with CM5 Lite 8 GB, SC1568) · **OS:** Raspberry Pi OS 64-bit

IMX219 camera on the 22-pin MIPI CSI-2 connectors MIPI1 and MIPI2: sensor detection, live video to a PC browser, Python frame capture, still photo and H.264 recording. Includes microSD preparation and first boot.

## Hardware
- IMX219 8 MP camera module, 22-pin MIPI CSI-2 FPC, on MIPI1 (or MIPI2)
- microSD card with Raspberry Pi OS 64-bit, Ethernet to the PC network

## Quick start (on the board)
```bash
sudo bash 01_install.sh            # install camera packages
sudo bash 02_config_camera.sh mipi1   # camera on MIPI1 (mipi2 / both), then reboot
sudo bash 03_diag.sh               # status summary
python3 svx_cam_stream.py          # live video: open http://<PI_IP>:8000/ on the PC
python3 svx_cam_capture.py photo -o photo.jpg
```

Full setup, connections and acceptance criteria: see the PDF test guide `SaturnVex_PCM5_MIPI_Camera_Test_Guide_EN.pdf`.
Copy this folder to the board (for example with `scp -r`) and run the scripts there; the guide shows the complete Windows PowerShell commands.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
