#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_cam_stream.py - live MJPEG view of the IMX219 camera on SVX-CPU-PCM5-001.
Open http://<PI_IP>:8000/ in a browser on a PC in the same network.

  python3 svx_cam_stream.py [--cam 0] [--size 1280x720] [--fps 30] [--port 8000] [--hflip] [--vflip]

Uses the Picamera2 library (BSD-2-Clause, Raspberry Pi Ltd) installed from the OS repository.
Only Python standard-library HTTP components are used for the web server.
"""
import argparse
import http.server
import io
import socket
import socketserver
import sys
import threading

try:
    from picamera2 import Picamera2
    from picamera2.encoders import MJPEGEncoder
    from picamera2.outputs import FileOutput
    from libcamera import Transform
except ImportError:
    sys.exit("picamera2 not found. Run: sudo bash 01_install.sh")

BOUNDARY = "svxframe"
HTML = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SVX-CPU-PCM5-001 camera</title></head>
<body style="margin:0;background:#101418;color:#d8dee4;font-family:sans-serif;text-align:center">
<p>SVX-CPU-PCM5-001 &middot; camera {cam} &middot; {w}x{h} @ {fps:g} fps</p>
<img src="/video" style="max-width:100%;height:auto" alt="live video"></body></html>"""


class LatestFrame(io.BufferedIOBase):
    """Receives JPEG frames from the encoder and keeps only the newest one."""

    def __init__(self):
        self._jpeg = b""
        self._seq = 0
        self._cv = threading.Condition()

    def write(self, data):
        with self._cv:
            self._jpeg, self._seq = bytes(data), self._seq + 1
            self._cv.notify_all()
        return len(data)

    def wait_next(self, last_seq, timeout=2.0):
        with self._cv:
            self._cv.wait_for(lambda: self._seq != last_seq, timeout=timeout)
            return self._jpeg, self._seq


def build_handler(frames, page):
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_):
            return

        def _send_page(self):
            body = page.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _send_video(self):
            self.send_response(200)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Type", f"multipart/x-mixed-replace; boundary={BOUNDARY}")
            self.end_headers()
            print("Viewer connected:", self.client_address[0])
            seq = -1
            try:
                while True:
                    jpeg, seq = frames.wait_next(seq)
                    if not jpeg:
                        continue
                    head = (f"--{BOUNDARY}\r\nContent-Type: image/jpeg\r\n"
                            f"Content-Length: {len(jpeg)}\r\n\r\n").encode()
                    self.wfile.write(head + jpeg + b"\r\n")
            except (BrokenPipeError, ConnectionResetError):
                print("Viewer left:", self.client_address[0])

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                self._send_page()
            elif self.path == "/video":
                self._send_video()
            else:
                self.send_error(404)
    return Handler


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def host_ip():
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        try:
            s.connect(("192.0.2.1", 9))      # documentation address; no packet is sent
            return s.getsockname()[0]
        except OSError:
            return "<PI_IP>"


def main():
    p = argparse.ArgumentParser(description="SVX-CPU-PCM5-001 camera web stream")
    p.add_argument("--cam", type=int, default=0)
    p.add_argument("--size", default="1280x720")
    p.add_argument("--fps", type=float, default=30)
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--hflip", action="store_true")
    p.add_argument("--vflip", action="store_true")
    a = p.parse_args()
    w, h = (int(v) for v in a.size.lower().split("x"))

    if not Picamera2.global_camera_info():
        sys.exit("No camera detected. Run: sudo bash 03_diag.sh")

    cam = Picamera2(a.cam)
    cam.configure(cam.create_video_configuration(
        main={"size": (w, h)}, controls={"FrameRate": a.fps},
        transform=Transform(hflip=int(a.hflip), vflip=int(a.vflip))))
    frames = LatestFrame()
    cam.start_recording(MJPEGEncoder(), FileOutput(frames))

    srv = Server(("", a.port), build_handler(frames, HTML.format(cam=a.cam, w=w, h=h, fps=a.fps)))
    print(f"Streaming. Open in a browser:  http://{host_ip()}:{a.port}/   (Ctrl+C to stop)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
        cam.stop_recording()
        cam.close()


if __name__ == "__main__":
    main()
