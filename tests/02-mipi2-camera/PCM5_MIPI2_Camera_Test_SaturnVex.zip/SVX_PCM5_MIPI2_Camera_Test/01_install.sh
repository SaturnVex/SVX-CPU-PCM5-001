#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 01_install.sh - install OS updates and MIPI2 camera test software.
# Usage : sudo bash 01_install.sh
# Safe to run more than once. Packages are installed from the official
# Debian / Raspberry Pi OS repositories; see NOTICE.txt for their licenses.
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
    echo "Run with sudo:  sudo bash $0"; exit 1
fi

echo "==> [1/3] Updating system (firmware, kernel, libcamera)"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get -y full-upgrade

echo "==> [2/3] Installing camera, Python and diagnostic packages"
# Desktop image -> rpicam-apps ; Lite image (no desktop) -> rpicam-apps-lite
if dpkg -s rpicam-apps >/dev/null 2>&1; then
    RPICAM=rpicam-apps
elif dpkg -s labwc >/dev/null 2>&1 || dpkg -s wayfire >/dev/null 2>&1 || dpkg -s xserver-xorg-core >/dev/null 2>&1; then
    RPICAM=rpicam-apps
else
    RPICAM=rpicam-apps-lite
fi
echo "    -> camera apps package: $RPICAM"

DEBIAN_FRONTEND=noninteractive apt-get install -y \
    "$RPICAM" python3-picamera2 python3-opencv python3-numpy \
    ffmpeg i2c-tools v4l-utils libcamera-tools raspi-utils

echo "==> [3/3] Adding user to video, i2c and gpio groups"
U="${SUDO_USER:-$(logname 2>/dev/null || echo pi)}"
for g in video i2c gpio; do
    if getent group "$g" >/dev/null; then usermod -aG "$g" "$U"; fi
done

echo
rpicam-hello --version 2>/dev/null | head -n 3 || true
python3 -c "import picamera2, cv2; print('picamera2 OK, OpenCV', cv2.__version__)"
echo
echo "STEP 1 DONE.  Next:  sudo bash 02_config_mipi2.sh enable"
