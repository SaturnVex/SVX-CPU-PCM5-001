#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 02_config_mipi2.sh - enable the IMX219 camera on connector MIPI2 only.
#
# Usage : sudo bash 02_config_mipi2.sh enable   # camera on MIPI2 -> dtoverlay=imx219 (cam1)
#         sudo bash 02_config_mipi2.sh show     # print current settings
#         sudo bash 02_config_mipi2.sh remove   # remove camera settings
#         then: sudo reboot
#
# MIPI2 on SVX-CPU-PCM5-001:
#   DPHY1 (cam1, the default port of dtoverlay=imx219)
#   I2C   SCL1/SDA1 = ID_SC/ID_SD (GPIO1/GPIO0) through jumper H4
#         -> BOTH H4 JUMPERS (1-2 and 3-4) MUST BE FITTED
#   Power enable pulled up to 3.3 V (always on)
#
# Uses the same config.txt markers as SVX_PCM5_MIPI_Camera_Test, so any
# camera block written by either package is replaced cleanly.
# Note: any MIPI1 (cam0) imx219 line is removed -> only MIPI2 is tested.
set -euo pipefail

MODE="${1:-}"
CFG=/boot/firmware/config.txt
[ -f "$CFG" ] || CFG=/boot/config.txt
BEGIN="# >>> SVX camera (02_config_mipi2.sh) >>>"
END="# <<< SVX camera (02_config_mipi2.sh) <<<"

show() {
    echo "----- $CFG (camera related lines) -----"
    grep -nE '^\[|camera_auto_detect|imx219|i2c_arm|SVX camera' "$CFG" || true
    echo "---------------------------------------"
}

case "$MODE" in
    enable) OVERLAYS=("dtoverlay=imx219") ;;
    remove) OVERLAYS=() ;;
    show)   show; exit 0 ;;
    *) echo "Argument: enable | show | remove"; exit 1 ;;
esac

if [ "$(id -u)" -ne 0 ]; then
    echo "Run with sudo:  sudo bash $0 $MODE"; exit 1
fi

# Keep the original file once, plus a time-stamped backup on every run
[ -f "${CFG}.orig" ] || cp "$CFG" "${CFG}.orig"
cp "$CFG" "${CFG}.$(date +%Y%m%d-%H%M%S).bak"

sed -i 's/\r$//' "$CFG"                                        # strip Windows line endings
sed -i '/^# >>> SVX camera/,/^# <<< SVX camera/d' "$CFG"       # remove previous SVX block
sed -i '/^# >>> camera-imx219/,/^# <<< camera-imx219/d' "$CFG" # remove legacy engineering block
sed -i -E '/^[[:space:]]*dtoverlay=imx219/d' "$CFG"            # remove stray imx219 lines

# Third-party (non Raspberry Pi) camera: disable auto-detect, declare overlay explicitly
sed -i -E 's/^[[:space:]]*camera_auto_detect=.*/camera_auto_detect=0/' "$CFG"
grep -q '^camera_auto_detect=0' "$CFG" || sed -i '1i camera_auto_detect=0' "$CFG"

sed -i -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$CFG"               # trim trailing blank lines
if [ "${#OVERLAYS[@]}" -gt 0 ]; then
    {
        echo ""
        echo "$BEGIN"
        echo "[all]"
        for o in "${OVERLAYS[@]}"; do echo "$o"; done
        echo "$END"
    } >> "$CFG"
fi

show
case "$MODE" in
    enable)
        echo "Camera on MIPI2 (cam1)."
        echo "CHECK HARDWARE BEFORE REBOOT:"
        echo "  - Both H4 jumpers fitted: 1-2 and 3-4 (MIPI2 I2C)"
        echo "  - FPC cable contacts facing the connector contacts, latch closed"
        ;;
    remove) echo "Camera settings removed." ;;
esac
echo "Original file kept at: ${CFG}.orig"
echo "Now run:  sudo reboot"
