#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 03_diag.sh - MIPI2 camera diagnostics with PASS/FAIL summary.
#         Full log is saved to diag_mipi2.txt (same folder).
# Usage : sudo bash 03_diag.sh
CFG=/boot/firmware/config.txt; [ -f "$CFG" ] || CFG=/boot/config.txt
OUT="$(cd "$(dirname "$0")" && pwd)/diag_mipi2.txt"

sec() { echo; echo "==================== $* ===================="; }

# imx219 device-tree nodes, found by compatible string (node name differs between overlays)
imx_nodes() {
    grep -rlas 'sony,imx219' /proc/device-tree --include=compatible 2>/dev/null | xargs -r -n1 dirname
}

{
sec "Date / model / OS"
date
tr -d '\0' < /proc/device-tree/model; echo
uname -a
grep -E 'PRETTY_NAME' /etc/os-release
rpicam-hello --version 2>&1 | head -n 3

sec "config.txt (active lines)"
grep -vE '^[[:space:]]*(#|$)' "$CFG"

sec "Firmware log: device tree and overlays"
vclog -m 2>/dev/null | grep -iE 'dtb|overlay|imx219|error|fail' | tail -n 40

sec "imx219 nodes in live device tree"
NODES=$(imx_nodes)
if [ -z "$NODES" ]; then
    echo "NO imx219 node -> overlay not loaded"
else
    for n in $NODES; do echo "$n  status=$(tr -d '\0' < "$n/status" 2>/dev/null || echo okay)"; done
fi

sec "Kernel log: imx219 / cfe / csi"
dmesg | grep -iE 'imx219|rp1-cfe|cfe|csi' | tail -n 60

sec "Kernel modules"
lsmod | grep -iE 'imx219|rp1_cfe|pisp'

sec "GPIO0/1 = ID_SD/ID_SC (MIPI2 I2C via H4) - expect an I2C alt function"
pinctrl get 0-1 2>/dev/null

sec "MIPI2 I2C bus (i2c-0): raw scan, 0x10 should answer when driver is NOT bound"
i2cdetect -y 0 2>&1

sec "I2C buses and IMX219 probe at 0x10 (UU = bound by driver, 10 = present, -- = absent)"
i2cdetect -l
for b in $(i2cdetect -l | awk '{print $1}' | sed 's/i2c-//'); do
    line=$(i2cdetect -y "$b" 0x10 0x10 2>/dev/null | grep '^10:')
    echo "i2c-$b : ${line:-scan error}"
done

sec "Media / video devices"
for m in /dev/media*; do
    [ -e "$m" ] || continue
    echo "--- $m"; media-ctl -d "$m" -p 2>/dev/null | grep -iE 'driver|model|imx219|csi' | head -n 10
done

sec "rpicam-hello --list-cameras"
rpicam-hello --list-cameras 2>&1 | tail -n 20
} > "$OUT" 2>&1

# ------------------------------------------------------------------ summary
FAIL=0
ok()  { printf '  [PASS] %s\n' "$1"; }
bad() { printf '  [FAIL] %s\n         -> %s\n' "$1" "$2"; FAIL=1; }

echo
echo "================ MIPI2 CAMERA SUMMARY ================"
if grep -qE '^[[:space:]]*dtoverlay=imx219[[:space:]]*$' "$CFG"; then
    ok "config.txt has dtoverlay=imx219 (cam1 / MIPI2)"
else
    bad "dtoverlay=imx219 for MIPI2 not found" "sudo bash 02_config_mipi2.sh enable && sudo reboot"
fi

if [ -n "$(imx_nodes)" ]; then
    ok "imx219 node present in device tree"
else
    bad "imx219 node missing" "overlay not loaded: check config.txt, then reboot"
fi

ERR=$(dmesg | grep -iE 'imx219.*(error|fail)' | tail -n 1)
if [ -n "$ERR" ]; then
    bad "imx219 driver error: $ERR" \
        "check H4 jumpers (1-2, 3-4), FPC cable direction/latch, camera module"
elif lsmod | grep -q imx219; then
    ok "imx219 driver loaded, no probe error"
else
    bad "imx219 driver not loaded" "overlay not active or kernel module missing"
fi

if rpicam-hello --list-cameras 2>&1 | grep -qi imx219; then
    ok "libcamera sees the imx219 camera"
else
    bad "libcamera lists no imx219 camera" "fix the items above first"
fi
echo "======================================================"
[ "$FAIL" -eq 0 ] && echo "RESULT: PASS  -> next: bash 04_quick_test.sh" \
                  || echo "RESULT: FAIL  -> send $OUT to SaturnVex support"
echo "Full log: $OUT"
