#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 04_quick_test.sh - functional test of the MIPI2 camera (works over SSH).
#         1) list cameras  2) 8 MP still  3) 5 s MJPEG video  4) FPS measurement
#         Output files are written to ./test_output/
# Usage : bash 04_quick_test.sh          (no sudo needed)
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
OUT="$DIR/test_output"
mkdir -p "$OUT"
FAIL=0
step() { echo; echo "==> $*"; }
res()  { if [ "$1" -eq 0 ]; then echo "    [PASS] $2"; else echo "    [FAIL] $2"; FAIL=1; fi; }

step "[1/4] Camera list"
LIST=$(rpicam-hello --list-cameras 2>&1)
echo "$LIST" | tail -n 12
echo "$LIST" | grep -qi imx219; res $? "imx219 detected"
if [ "$FAIL" -ne 0 ]; then
    echo "No camera -> run: sudo bash 03_diag.sh"; exit 1
fi

step "[2/4] Still photo 3280x2464"
rpicam-still -n --camera 0 -t 2000 --width 3280 --height 2464 \
    -o "$OUT/mipi2_still.jpg" >/dev/null 2>&1
[ -s "$OUT/mipi2_still.jpg" ]; res $? "mipi2_still.jpg ($(du -h "$OUT/mipi2_still.jpg" 2>/dev/null | cut -f1))"

step "[3/4] Video 1920x1080 30 fps, 5 s, MJPEG"
rpicam-vid -n --camera 0 -t 5000 --width 1920 --height 1080 --framerate 30 \
    --codec mjpeg -o "$OUT/mipi2_video.mjpeg" >/dev/null 2>&1
[ -s "$OUT/mipi2_video.mjpeg" ]; res $? "mipi2_video.mjpeg ($(du -h "$OUT/mipi2_video.mjpeg" 2>/dev/null | cut -f1))"

step "[4/4] Frame rate, 1920x1080 RGB, 5 s"
python3 "$DIR/svx_cam_capture.py" frames --size 1920x1080 --fps 30 --duration 5
res $? "frame capture"

echo
[ "$FAIL" -eq 0 ] && echo "RESULT: MIPI2 CAMERA PASS" || echo "RESULT: MIPI2 CAMERA FAIL"
echo "Files: $OUT"
echo "Copy to PC:  scp -r <user>@<PI_IP>:$OUT ."
exit "$FAIL"
