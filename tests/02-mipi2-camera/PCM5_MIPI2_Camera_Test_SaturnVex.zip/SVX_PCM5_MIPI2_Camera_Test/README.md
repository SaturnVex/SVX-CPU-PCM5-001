# MIPI2 Camera (DPHY1) Test

**Package:** `SVX_PCM5_MIPI2_Camera_Test` · **Board:** `SVX-CPU-PCM5-001` · **Module:** Raspberry Pi CM5 (tested with CM5 Lite 8 GB, SC1568) · **OS:** Raspberry Pi OS 64-bit

Dedicated test of connector MIPI2 with an IMX219 camera: I²C detection through jumper H4, automatic functional test (still, video, frame rate), live video to a PC browser.

## Hardware
- IMX219 camera on connector MIPI2 (DPHY1 / cam1)
- Jumper H4: fit both 1-2 and 3-4 (routes the MIPI2 I²C bus to ID_SC / ID_SD)

## Quick start (on the board)
```bash
sudo bash 01_install.sh
sudo bash 02_config_mipi2.sh enable   # then reboot
sudo bash 03_diag.sh                  # all items PASS
bash 04_quick_test.sh                 # list, still, video, FPS -> test_output/
python3 svx_cam_stream.py             # open http://<PI_IP>:8000/
```

Full setup, connections and acceptance criteria: see the PDF test guide `SaturnVex_PCM5_MIPI2_Camera_Test_Guide_EN.pdf`.
Copy this folder to the board (for example with `scp -r`) and run the scripts there; the guide shows the complete Windows PowerShell commands.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
