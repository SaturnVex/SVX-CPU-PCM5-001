SVX_PCM5_MIPI2_Camera_Test - IMX219 camera on connector MIPI2 (SVX-CPU-PCM5-001)

HARDWARE
  - Camera IMX219 (e.g. DFRobot SEN0630) on connector MIPI2 (DPHY1 / cam1)
  - Jumper H4: fit BOTH 1-2 and 3-4 (routes MIPI2 I2C to ID_SC/ID_SD)
  - FPC cable: contacts facing the connector contacts, latch closed

STEPS (copy the folder to the Pi, e.g. ~/SVX_PCM5_MIPI2_Camera_Test)
  1. sudo bash 01_install.sh               install / update packages
  2. sudo bash 02_config_mipi2.sh enable   write dtoverlay=imx219 (cam1)
     sudo reboot
  3. sudo bash 03_diag.sh                  status summary (all items PASS)
  4. bash 04_quick_test.sh                 list, still, video, FPS -> test_output/

EXTRA
  python3 svx_cam_capture.py list
  python3 svx_cam_capture.py frames --show            (desktop only)
  python3 svx_cam_capture.py photo -o photo.jpg
  python3 svx_cam_capture.py record -o video.mp4 -t 10
  python3 svx_cam_stream.py      then open http://<PI_IP>:8000/

Full guide: SaturnVex_PCM5_MIPI2_Camera_Test_Guide_EN.pdf
