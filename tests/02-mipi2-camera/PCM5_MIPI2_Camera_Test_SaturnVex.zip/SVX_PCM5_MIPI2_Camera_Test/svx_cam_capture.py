#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_cam_capture.py - IMX219 camera test on connector MIPI2 of board SVX-CPU-PCM5-001.

  python3 svx_cam_capture.py list                       # cameras and sensor modes
  python3 svx_cam_capture.py frames                     # read frames, print FPS (works over SSH)
  python3 svx_cam_capture.py frames --duration 5        # stop after 5 s (exit 1 if no frame)
  python3 svx_cam_capture.py frames --show              # also display window (needs desktop)
  python3 svx_cam_capture.py photo  -o photo.jpg        # 8 MP still
  python3 svx_cam_capture.py record -o video.mp4 -t 10  # 10 s H.264 video

Options: --cam N  --size WxH  --fps F  --hflip  --vflip
With 02_config_mipi2.sh only MIPI2 is enabled, so the MIPI2 camera is index 0.
Uses the Picamera2 library (BSD-2-Clause, Raspberry Pi Ltd) installed from the OS repository.
"""
import argparse
import sys
import time

try:
    from picamera2 import Picamera2
    from libcamera import Transform
except ImportError:
    sys.exit("picamera2 not found. Run: sudo bash 01_install.sh")


def wh(text):
    w, h = text.lower().split("x")
    return int(w), int(h)


def get_camera(index):
    cams = Picamera2.global_camera_info()
    if not cams:
        sys.exit("No camera detected on MIPI2. Run: sudo bash 03_diag.sh")
    if index >= len(cams):
        sys.exit(f"Camera {index} not found; {len(cams)} camera(s) available.")
    print(f"Using camera {index}: {cams[index].get('Model')}  {cams[index].get('Id')}")
    return Picamera2(index)


def flip(a):
    return Transform(hflip=int(a.hflip), vflip=int(a.vflip))


def do_list(_a):
    cams = Picamera2.global_camera_info()
    if not cams:
        print("No camera detected on MIPI2. Run: sudo bash 03_diag.sh")
        return 1
    for i, c in enumerate(cams):
        print(f"[{i}] {c.get('Model')}  {c.get('Id')}")
        with Picamera2(i) as cam:
            for m in cam.sensor_modes:
                print(f"     {m['size'][0]}x{m['size'][1]}  {m['fps']:.1f} fps  {m['bit_depth']}-bit")
    return 0


def do_frames(a):
    cam = get_camera(a.cam)
    w, h = wh(a.size or "1920x1080")
    # "RGB888" in libcamera is stored as B,G,R bytes: directly usable by OpenCV
    cam.configure(cam.create_video_configuration(
        main={"size": (w, h), "format": "RGB888"},
        controls={"FrameRate": a.fps}, transform=flip(a), buffer_count=4))
    cam.start()
    time.sleep(1.0)                       # let exposure / white balance settle

    cv2 = None
    if a.show:
        import cv2                        # noqa: F811

    stop = f"{a.duration:g} s" if a.duration else "Ctrl+C"
    print(f"Reading {w}x{h} @ {a.fps:g} fps. Stop: {stop}.")
    total, count = 0, 0
    t_begin = t_start = time.monotonic()
    try:
        while True:
            img = cam.capture_array("main")   # numpy uint8 (h, w, 3), BGR order
            count += 1
            total += 1
            # ---- place your image processing here ----
            if cv2 is not None:
                cv2.imshow("SVX-CPU-PCM5-001 MIPI2 camera", img)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            now = time.monotonic()
            if now - t_start >= 2.0:
                print(f"FPS {count / (now - t_start):5.1f} | shape {img.shape} | mean {img.mean():.1f}")
                count, t_start = 0, now
            if a.duration and now - t_begin >= a.duration:
                break
    except KeyboardInterrupt:
        pass
    finally:
        cam.stop()
        cam.close()
        if cv2 is not None:
            cv2.destroyAllWindows()
    elapsed = time.monotonic() - t_begin
    print(f"Total {total} frames in {elapsed:.1f} s -> average {total / max(elapsed, 1e-6):.1f} fps")
    return 0 if total > 0 else 1


def do_photo(a):
    cam = get_camera(a.cam)
    cam.configure(cam.create_still_configuration(
        main={"size": wh(a.size or "3280x2464")}, transform=flip(a)))
    cam.start()
    time.sleep(2.0)
    out = a.output or "photo.jpg"
    cam.capture_file(out)
    cam.stop()
    cam.close()
    print("Saved", out)
    return 0


def do_record(a):
    from picamera2.encoders import H264Encoder
    from picamera2.outputs import FfmpegOutput
    cam = get_camera(a.cam)
    cam.configure(cam.create_video_configuration(
        main={"size": wh(a.size or "1920x1080")},
        controls={"FrameRate": a.fps}, transform=flip(a)))
    out = a.output or "video.mp4"
    # CM5 has no hardware H.264 encoder; Picamera2 uses software encoding.
    cam.start_recording(H264Encoder(bitrate=10_000_000), FfmpegOutput(out))
    print(f"Recording {a.time:g} s -> {out}")
    try:
        time.sleep(a.time)
    except KeyboardInterrupt:
        pass
    cam.stop_recording()
    cam.close()
    print("Saved", out)
    return 0


def main():
    p = argparse.ArgumentParser(description="SVX-CPU-PCM5-001 MIPI2 IMX219 camera test")
    p.add_argument("mode", choices=["list", "frames", "photo", "record"])
    p.add_argument("--cam", type=int, default=0)
    p.add_argument("--size")
    p.add_argument("--fps", type=float, default=30)
    p.add_argument("--duration", type=float, default=0, help="frames: stop after N seconds")
    p.add_argument("--hflip", action="store_true")
    p.add_argument("--vflip", action="store_true")
    p.add_argument("--show", action="store_true")
    p.add_argument("-o", "--output")
    p.add_argument("-t", "--time", type=float, default=10)
    a = p.parse_args()
    modes = {"list": do_list, "frames": do_frames, "photo": do_photo, "record": do_record}
    sys.exit(modes[a.mode](a))


if __name__ == "__main__":
    main()
