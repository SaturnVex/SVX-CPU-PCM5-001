#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 01_setup.sh - install GPIO/UART test tools and enable UART1 on H3 pins 1-2.
# Usage : sudo bash 01_setup.sh          then: sudo reboot
#
# UART1 (RP1) -> /dev/ttyAMA1 : TX = GPIO0 = H3 pin 1 (ID_SD)
#                               RX = GPIO1 = H3 pin 2 (ID_SC)
# GPIO0/1 are shared with MIPI2 camera I2C (through jumper H4). Remove both H4
# jumpers and do not use a camera on MIPI2 (cam1) while UART1 is enabled.
set -euo pipefail

CFG=/boot/firmware/config.txt
[ -f "$CFG" ] || CFG=/boot/config.txt
BEGIN="# >>> SVX gpio-uart (01_setup.sh) >>>"
END="# <<< SVX gpio-uart (01_setup.sh) <<<"

if [ "$(id -u)" -ne 0 ]; then echo "Run with sudo:  sudo bash $0"; exit 1; fi

echo "==> [1/4] Installing packages"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3-libgpiod python3-serial gpiod raspi-utils

echo "==> [2/4] Checking conflicts on GPIO0/GPIO1"
CONFLICT=0
if grep -qE '^[[:space:]]*dtoverlay=imx219[[:space:]]*$|^[[:space:]]*dtoverlay=[a-z0-9_]+,cam1' "$CFG"; then
    echo "  !! A camera is configured on MIPI2 (cam1); it uses GPIO0/1 for I2C."; CONFLICT=1
fi
if grep -qE '^[[:space:]]*dtparam=i2c_vc=on|^[[:space:]]*dtoverlay=i2c0' "$CFG"; then
    echo "  !! i2c_vc / i2c0 is enabled; it uses GPIO0/1."; CONFLICT=1
fi
if grep -qE '^[[:space:]]*dtparam=(i2c_arm|spi)=on' "$CFG"; then
    echo "  note: i2c_arm (GPIO2/3) or spi (GPIO7-11) is on; those H3 pins will be busy for the GPIO test."
fi
if [ "$CONFLICT" = 1 ] && [ "${1:-}" != "--force" ]; then
    echo "Resolve the conflict above (or re-run with --force). Nothing changed."; exit 1
fi

echo "==> [3/4] Enabling UART1 on GPIO0/1 in $CFG"
[ -f "${CFG}.orig" ] || cp "$CFG" "${CFG}.orig"
cp "$CFG" "${CFG}.$(date +%Y%m%d-%H%M%S).bak"
sed -i 's/\r$//' "$CFG"
sed -i '/^# >>> SVX gpio-uart/,/^# <<< SVX gpio-uart/d' "$CFG"
sed -i -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$CFG"
{
    echo ""
    echo "$BEGIN"
    echo "[all]"
    echo "dtoverlay=uart1-pi5"
    echo "$END"
} >> "$CFG"
grep -nE 'uart1-pi5|imx219|SVX' "$CFG" || true

echo "==> [4/4] Adding user to gpio and dialout groups"
U="${SUDO_USER:-$(logname 2>/dev/null || echo pi)}"
for g in gpio dialout; do
    if getent group "$g" >/dev/null; then usermod -aG "$g" "$U"; fi
done

echo
echo "Remove both H4 jumpers, then:  sudo reboot"
echo "After reboot check:  ls -l /dev/ttyAMA1   and   pinctrl get 0-1"
