# H3 GPIO & UART Test

**Package:** `SVX_PCM5_GPIO_UART_Test` · **Board:** `SVX-CPU-PCM5-001` · **Module:** Raspberry Pi CM5 (tested with CM5 Lite 8 GB, SC1568) · **OS:** Raspberry Pi OS 64-bit

All 20 GPIO signals of header H3 (output toggle, per-pin identification, automatic open / short check) and UART1 on H3 pins 1–2, in loopback and to a Windows PC.

## Hardware
- Header H3 (2 × 12, 2.54 mm): 20 GPIO, UART1 on pins 1–2
- 3.3 V USB-UART adapter for the PC test (optional)

## Quick start
```bash
sudo bash 01_setup.sh                    # on the board, once
python3 svx_gpio_toggle.py list          # GPIO map; also blink / walk / short
python3 svx_uart_test.py echo            # board side of the UART test
python pc_uart_test.py --port COM5       # on the PC (pip install pyserial)
```

Full setup, connections and acceptance criteria: see the PDF test guide `SaturnVex_PCM5_GPIO_UART_Test_Guide_EN.pdf`.
Copy this folder to the board (for example with `scp -r`) and run the scripts there; the guide shows the complete Windows PowerShell commands.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
