#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
pc_uart_test.py - PC side (Windows/Linux) of the SVX-CPU-PCM5-001 UART1 test.
Board must run:  python3 svx_uart_test.py echo

  pip install pyserial
  python pc_uart_test.py --list                    # show COM ports
  python pc_uart_test.py --port COM5               # 200 packets, verify echo
  python pc_uart_test.py --port COM5 --baud 921600 --count 1000
"""
import argparse
import os
import sys
import time

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    sys.exit("pyserial missing. Run: pip install pyserial")


def main():
    p = argparse.ArgumentParser(description="PC side UART echo test for SVX-CPU-PCM5-001")
    p.add_argument("--port")
    p.add_argument("--baud", type=int, default=115200)
    p.add_argument("--count", type=int, default=200)
    p.add_argument("--list", action="store_true")
    a = p.parse_args()

    if a.list or not a.port:
        for port in list_ports.comports():
            print(f"{port.device:8} {port.description}")
        if not a.port:
            print("\nUse: python pc_uart_test.py --port COMx")
        return

    ok, nbytes = 0, 0
    with serial.Serial(a.port, a.baud, timeout=1.0) as s:
        time.sleep(0.2)
        s.reset_input_buffer()
        t0 = time.monotonic()
        for i in range(a.count):
            msg = f"SVX{i:05d}:{os.urandom(12).hex()}\n".encode()
            s.write(msg)
            rx = s.read(len(msg))
            nbytes += len(msg)
            if rx == msg:
                ok += 1
            else:
                print(f"FAIL #{i}: sent {msg!r} got {rx!r}")
        dt = time.monotonic() - t0
    print(f"{a.port} @ {a.baud}: {ok}/{a.count} packets PASS, "
          f"{nbytes} bytes each way in {dt:.2f} s")
    sys.exit(0 if ok == a.count else 1)


if __name__ == "__main__":
    main()
