#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_gpio_toggle.py - GPIO test of header H3 on board SVX-CPU-PCM5-001.

  python3 svx_gpio_toggle.py list                  # H3 pin map
  python3 svx_gpio_toggle.py blink  [--hz 1]       # all pins toggle together (LED / meter / scope)
  python3 svx_gpio_toggle.py walk   [--hold 1.0]   # one pin HIGH at a time, pin number printed
  python3 svx_gpio_toggle.py short                 # automatic open/short test, no instrument needed

Options: --pins 5,6,7   test only these GPIO numbers
         --all          also test GPIO0/1 when UART1 (/dev/ttyAMA1) is enabled,
                        and GPIO2/3 when I2C1 (/dev/i2c-1) is enabled
Uses libgpiod Python bindings (LGPL-2.1-or-later) installed from the OS repository.
Header H3: 3.3 V logic only. Do not connect 5 V signals. Max ~8 mA per pin.
"""
import argparse
import glob
import os
import sys
import time

try:
    import gpiod
    from gpiod.line import Bias, Direction, Value
except ImportError:
    sys.exit("python3-libgpiod (v2) not found. Run: sudo bash 01_setup.sh")

# H3 pin -> GPIO (from schematic SVX-CPU-PCM5-001). Pins 21=+3.3V, 22=+5V, 23/24=GND.
H3 = {
    1: 0,   2: 1,     # ID_SD / ID_SC  (UART1 TX / RX when enabled)
    3: 6,   4: 21,
    5: 5,   6: 20,
    7: 11,  8: 16,
    9: 9,   10: 12,
    11: 22, 12: 7,
    13: 27, 14: 8,
    15: 17, 16: 23,
    17: 3,  18: 25,
    19: 2,  20: 24,
}
GPIO_TO_PIN = {g: p for p, g in H3.items()}
UART_GPIOS = (0, 1)
I2C1_GPIOS = (2, 3)


def find_chip():
    """Return the RP1 GPIO chip path (label 'pinctrl-rp1')."""
    for path in sorted(glob.glob("/dev/gpiochip*")):
        try:
            with gpiod.Chip(path) as chip:
                info = chip.get_info()
                if "rp1" in info.label and info.num_lines >= 28:
                    return path
        except OSError:
            continue
    sys.exit("RP1 GPIO chip not found (check: gpiodetect)")


def select_gpios(args):
    if args.pins:
        gpios = [int(x) for x in args.pins.split(",")]
        bad = [g for g in gpios if g not in GPIO_TO_PIN]
        if bad:
            sys.exit(f"GPIO {bad} not on H3. Valid: {sorted(GPIO_TO_PIN)}")
    else:
        gpios = [H3[p] for p in sorted(H3)]
    if os.path.exists("/dev/ttyAMA1") and not args.all:
        skipped = [g for g in gpios if g in UART_GPIOS]
        gpios = [g for g in gpios if g not in UART_GPIOS]
        if skipped:
            print("UART1 enabled -> GPIO0/1 (H3 pin 1/2) skipped. Use --all to include.")
    if os.path.exists("/dev/i2c-1") and not args.all:
        skipped = [g for g in gpios if g in I2C1_GPIOS]
        gpios = [g for g in gpios if g not in I2C1_GPIOS]
        if skipped:
            print("I2C1 enabled -> GPIO2/3 (H3 pin 19/17) skipped. Use --all to include.")
    return gpios


def label(g):
    return f"H3-{GPIO_TO_PIN[g]:<2} GPIO{g:<2}"


OUT_LOW = gpiod.LineSettings(direction=Direction.OUTPUT, output_value=Value.INACTIVE)
OUT_HIGH = gpiod.LineSettings(direction=Direction.OUTPUT, output_value=Value.ACTIVE)
IN_PD = gpiod.LineSettings(direction=Direction.INPUT, bias=Bias.PULL_DOWN)


def do_list(_a):
    print("H3 pin  GPIO   | H3 pin  GPIO")
    for p in range(1, 21, 2):
        print(f"  {p:>2}    GPIO{H3[p]:<2}  |   {p + 1:>2}    GPIO{H3[p + 1]:<2}")
    print("  21    +3.3V   |   22    +5V\n  23    GND     |   24    GND")


def do_blink(a):
    gpios = select_gpios(a)
    half = 0.5 / a.hz
    print(f"Toggling {len(gpios)} pins at {a.hz:g} Hz. Ctrl+C to stop.")
    with gpiod.request_lines(find_chip(), consumer="svx-h3-blink",
                             config={tuple(gpios): OUT_LOW}) as req:
        level, n = Value.INACTIVE, 0
        try:
            while True:
                level = Value.ACTIVE if level == Value.INACTIVE else Value.INACTIVE
                req.set_values({g: level for g in gpios})
                n += 1
                if a.hz <= 5:
                    print(f"\r{'HIGH' if level == Value.ACTIVE else 'LOW '}  cycles={n // 2}", end="", flush=True)
                time.sleep(half)
        except KeyboardInterrupt:
            req.set_values({g: Value.INACTIVE for g in gpios})
            print("\nStopped, all pins LOW.")


def do_walk(a):
    gpios = select_gpios(a)
    print(f"Walking HIGH over {len(gpios)} pins, {a.hold:g} s each. Ctrl+C to stop.")
    with gpiod.request_lines(find_chip(), consumer="svx-h3-walk",
                             config={tuple(gpios): OUT_LOW}) as req:
        try:
            while True:
                for g in gpios:
                    req.set_values({x: (Value.ACTIVE if x == g else Value.INACTIVE) for x in gpios})
                    print(f"HIGH -> {label(g)}")
                    time.sleep(a.hold)
        except KeyboardInterrupt:
            req.set_values({g: Value.INACTIVE for g in gpios})
            print("Stopped, all pins LOW.")


def do_short(a):
    """Drive one pin HIGH, others input with pull-down; any other pin reading HIGH = short."""
    gpios = select_gpios(a)
    fails = 0
    with gpiod.request_lines(find_chip(), consumer="svx-h3-short",
                             config={tuple(gpios): IN_PD}) as req:
        time.sleep(0.01)
        base = req.get_values(gpios)
        stuck = [g for g, v in zip(gpios, base) if v == Value.ACTIVE]
        for g in stuck:
            print(f"WARN  {label(g)} reads HIGH with pull-down (external pull-up or short to 3.3 V)")
        for g in gpios:
            others = [x for x in gpios if x != g]
            req.reconfigure_lines(config={g: OUT_HIGH, tuple(others): IN_PD})
            time.sleep(0.005)
            hit = [x for x, v in zip(others, req.get_values(others))
                   if v == Value.ACTIVE and x not in stuck]
            # read back the driven pin as input to confirm it is not shorted to GND
            req.reconfigure_lines(config={g: gpiod.LineSettings(direction=Direction.INPUT, bias=Bias.PULL_UP),
                                          tuple(others): IN_PD})
            time.sleep(0.005)
            low = req.get_values([g])[0] == Value.INACTIVE
            status = []
            if hit:
                status.append("SHORT to " + ", ".join(label(x).strip() for x in hit))
            if low:
                status.append("stuck LOW (short to GND?)")
            print(f"{'FAIL' if status else 'PASS'}  {label(g)}  {'; '.join(status)}")
            fails += bool(status)
        req.reconfigure_lines(config={tuple(gpios): IN_PD})
    print(f"\nResult: {len(gpios) - fails}/{len(gpios)} pins PASS")
    print("Note: leave H3 unconnected during this test (no loads, no jumpers).")
    sys.exit(1 if fails else 0)


def main():
    p = argparse.ArgumentParser(description="SVX-CPU-PCM5-001 header H3 GPIO test")
    p.add_argument("mode", choices=["list", "blink", "walk", "short"])
    p.add_argument("--hz", type=float, default=1.0)
    p.add_argument("--hold", type=float, default=1.0)
    p.add_argument("--pins")
    p.add_argument("--all", action="store_true")
    a = p.parse_args()
    try:
        {"list": do_list, "blink": do_blink, "walk": do_walk, "short": do_short}[a.mode](a)
    except OSError as e:
        sys.exit(f"GPIO request failed: {e}. "
                 "A pin may be claimed by another function (dtparam=i2c_arm=on uses GPIO2/3, "
                 "dtparam=spi=on uses GPIO7-11, UART1 uses GPIO0/1). Check: pinctrl get 0-27")


if __name__ == "__main__":
    main()
