#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_uart_test.py - UART1 test on header H3 of board SVX-CPU-PCM5-001 (runs on the board).

  H3 pin 1 = GPIO0 = TX  -> USB-UART adapter RX
  H3 pin 2 = GPIO1 = RX  <- USB-UART adapter TX
  H3 pin 23/24 = GND     -- USB-UART adapter GND      (3.3 V logic adapter only)

  python3 svx_uart_test.py loop            # self-test: jumper H3 pin 1 to pin 2, no PC needed
  python3 svx_uart_test.py echo            # echo every byte back to the PC (use with pc_uart_test.py)
  python3 svx_uart_test.py send            # send a numbered line every second, print what is received

Options: --port /dev/ttyAMA1  --baud 115200
Uses pySerial (BSD-3-Clause) installed from the OS repository.
"""
import argparse
import os
import sys
import time

try:
    import serial
except ImportError:
    sys.exit("python3-serial not found. Run: sudo bash 01_setup.sh")


def open_port(a):
    if not os.path.exists(a.port):
        sys.exit(f"{a.port} not found. Run 01_setup.sh and reboot.")
    return serial.Serial(a.port, a.baud, timeout=0.2)


def do_loop(a):
    """TX->RX loopback with a jumper across H3 pin 1-2."""
    ok = 0
    with open_port(a) as s:
        s.reset_input_buffer()
        for i in range(a.count):
            msg = f"SVX-LOOP-{i:04d}-{os.urandom(6).hex()}\n".encode()
            s.write(msg)
            s.flush()
            rx = s.read(len(msg))
            good = rx == msg
            ok += good
            if not good:
                print(f"FAIL #{i}: sent {msg!r} got {rx!r}")
    print(f"Loopback {a.baud} baud: {ok}/{a.count} PASS")
    if ok == 0:
        print("No data: check jumper on H3 pin 1-2 and that 'pinctrl get 0-1' shows TXD1/RXD1.")
    sys.exit(0 if ok == a.count else 1)


def do_echo(a):
    print(f"Echo on {a.port} @ {a.baud}. Ctrl+C to stop.")
    total = 0
    with open_port(a) as s:
        s.write(b"SVX-CPU-PCM5-001 UART1 echo ready\r\n")
        try:
            while True:
                data = s.read(s.in_waiting or 1)
                if data:
                    s.write(data)
                    total += len(data)
                    print(f"\rRX/TX bytes: {total}", end="", flush=True)
        except KeyboardInterrupt:
            print(f"\nStopped. Echoed {total} bytes.")


def do_send(a):
    print(f"Sending on {a.port} @ {a.baud} every 1 s. Ctrl+C to stop.")
    n = 0
    with open_port(a) as s:
        try:
            while True:
                s.write(f"SVX-CPU-PCM5-001 UART1 msg {n}\r\n".encode())
                n += 1
                t_end = time.monotonic() + 1.0
                while time.monotonic() < t_end:
                    data = s.read(s.in_waiting or 1)
                    if data:
                        print("RX:", data.decode(errors="replace").rstrip())
        except KeyboardInterrupt:
            print(f"\nStopped after {n} messages.")


def main():
    p = argparse.ArgumentParser(description="SVX-CPU-PCM5-001 UART1 test")
    p.add_argument("mode", choices=["loop", "echo", "send"])
    p.add_argument("--port", default="/dev/ttyAMA1")
    p.add_argument("--baud", type=int, default=115200)
    p.add_argument("--count", type=int, default=100)
    a = p.parse_args()
    {"loop": do_loop, "echo": do_echo, "send": do_send}[a.mode](a)


if __name__ == "__main__":
    main()
