#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 01_setup.sh - set USB 2.0 port J1 (USB-C) to USB device mode for the USB test.
#         J1 is used only as a USB device on this board (host mode is not supported).
# Usage : sudo bash 01_setup.sh device    J1 = USB device to a PC (no H1 jumper)     then: sudo reboot
#                                         Board powered from DC jack U1, J1 to PC with a USB cable.
#         sudo bash 01_setup.sh remove    undo all changes                           then: sudo reboot
#
# J1 D+/D- -> CM5 USB_P/USB_N (CN2 pin 5/3), DWC2 controller. USB_OTG_ID (CN2 pin 1) -> H1 pin 8.
# Other dtoverlay=dwc2 lines in config.txt (e.g. the [cm5] default) are commented out with "#SVX# ".
set -euo pipefail

CFG=/boot/firmware/config.txt
[ -f "$CFG" ] || CFG=/boot/config.txt
BEGIN="# >>> SVX usb-j1 (01_setup.sh) >>>"
END="# <<< SVX usb-j1 (01_setup.sh) <<<"
DIR=/opt/svx-usb
UNIT=/etc/systemd/system/svx-usb-gadget.service
SRC="$(cd "$(dirname "$0")" && pwd)"
MODE="${1:-}"

if [ "$(id -u)" -ne 0 ]; then echo "Run with sudo:  sudo bash $0 device|remove"; exit 1; fi
case "$MODE" in device|remove) ;; *) echo "Usage: sudo bash $0 device|remove   (J1 device mode only)"; exit 1 ;; esac

clean_cfg() {
    sed -i 's/\r$//' "$CFG"
    sed -i '/^# >>> SVX usb-j1/,/^# <<< SVX usb-j1/d' "$CFG"
    sed -i -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$CFG"
}

remove_gadget() {
    if [ -f "$UNIT" ]; then
        systemctl disable --now svx-usb-gadget.service 2>/dev/null || true
        rm -f "$UNIT"
        systemctl daemon-reload
    fi
    rm -rf "$DIR"
}

[ -f "${CFG}.orig" ] || cp "$CFG" "${CFG}.orig"
cp "$CFG" "${CFG}.$(date +%Y%m%d-%H%M%S).bak"

if [ "$MODE" = remove ]; then
    clean_cfg
    sed -i 's/^#SVX# //' "$CFG"
    remove_gadget
    echo "USB J1 test settings removed. Now:  sudo reboot"
    exit 0
fi

echo "==> [1/4] Installing packages"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3-serial usbutils dosfstools

echo "==> [2/4] Setting dwc2 to device (peripheral) mode in $CFG"
clean_cfg
sed -i -E 's/^([[:space:]]*dtoverlay=dwc2.*)$/#SVX# \1/' "$CFG"
{
    echo ""
    echo "$BEGIN"
    echo "[all]"
    echo "dtoverlay=dwc2,dr_mode=peripheral"
    echo "$END"
} >> "$CFG"
grep -nE 'dwc2|SVX usb' "$CFG" || true

echo "==> [3/4] USB gadget service"
install -d "$DIR"
install -m 755 "$SRC/svx_usb_gadget.sh" "$DIR/svx_usb_gadget.sh"
sed -i 's/\r$//' "$DIR/svx_usb_gadget.sh"
rm -f "$DIR/msc.img"                   # fresh 64 MB FAT image for the USB drive test
dd if=/dev/zero of="$DIR/msc.img" bs=1M count=64 status=none
mkfs.vfat -n SVX_TEST "$DIR/msc.img" >/dev/null
echo "  USB drive image $DIR/msc.img (64 MB, FAT, label SVX_TEST)"
cat > "$UNIT" <<EOF
[Unit]
Description=SVX USB CDC-ACM gadget on J1 (/dev/ttyGS0)
After=sys-kernel-config.mount systemd-modules-load.service

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=$DIR/svx_usb_gadget.sh start
ExecStop=$DIR/svx_usb_gadget.sh stop

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable svx-usb-gadget.service
echo "  svx-usb-gadget.service enabled (starts after reboot)"

echo "==> [4/4] Adding user to dialout group"
U="${SUDO_USER:-$(logname 2>/dev/null || echo pi)}"
getent group dialout >/dev/null && usermod -aG dialout "$U"

echo
echo "Remove jumpers H1 pin 7-8 and H1 pin 1-2. Power stays on the DC jack U1. Then:  sudo reboot"
echo "Connect J1 to the PC with a USB cable."
echo "After reboot: python3 svx_usb_test.py status"
