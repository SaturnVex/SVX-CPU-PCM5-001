# USB-C Device & USB Boot Test

**Package:** `SVX_PCM5_USB_Test` · **Board:** `SVX-CPU-PCM5-001` · **Module:** Raspberry Pi CM5 (tested with CM5 Lite 8 GB, SC1568) · **OS:** Raspberry Pi OS 64-bit

USB-C connector J1 as a USB 2.0 device port to a Windows PC: enumeration, serial data transfer, USB drive read/write, cable re-plug, and CM5 USB boot mode (rpiboot) for access to the boot storage.

## Hardware
- USB-C connector J1 (USB 2.0 High-Speed device) to the PC; board powered from the DC jack
- Jumper header H1 (nRPIBOOT for USB boot mode)

## Quick start
```bash
sudo bash 01_setup.sh device             # on the board, then reboot
python3 svx_usb_test.py echo             # board side
python pc_usb_test.py                    # on the PC: serial echo test
python pc_usb_test.py --msc              # USB drive write / read-back test
```

Full setup, connections and acceptance criteria: see the PDF test guide `SaturnVex_PCM5_USB_C_Device_Test_Guide_EN.pdf`.
Copy this folder to the board (for example with `scp -r`) and run the scripts there; the guide shows the complete Windows PowerShell commands.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
