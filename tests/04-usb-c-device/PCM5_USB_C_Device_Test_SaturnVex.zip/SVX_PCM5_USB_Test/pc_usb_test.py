#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
pc_usb_test.py - PC side (Windows/Linux) of the SVX-CPU-PCM5-001 USB-C J1 device-mode test.
Board: sudo bash 01_setup.sh device + reboot. Board powered from DC jack U1.

  pip install pyserial
  python pc_usb_test.py --list                    # show COM ports, board marked with <-- SVX
  python pc_usb_test.py                           # serial: 1000 x 512-byte echo packets
  python pc_usb_test.py --count 2000 --size 4096  #   (board runs: python3 svx_usb_test.py echo)
  python pc_usb_test.py --msc                     # USB drive SVX_TEST: write 32 MB, read back, sha256
"""
import argparse
import hashlib
import os
import string
import sys
import time

SVX_VID, SVX_PID = 0x1D6B, 0x0104
MSC_LABEL = "SVX_TEST"
MSC_FILE = "SVXTEST.BIN"


def find_msc_drive():
    """Return the root path of the volume labelled SVX_TEST, or None."""
    if os.name == "nt":
        import ctypes
        k32 = ctypes.windll.kernel32
        mask = k32.GetLogicalDrives()
        for i, letter in enumerate(string.ascii_uppercase):
            if mask >> i & 1:
                root = f"{letter}:\\"
                buf = ctypes.create_unicode_buffer(261)
                if k32.GetVolumeInformationW(root, buf, 261, None, None, None, None, 0) \
                        and buf.value.upper() == MSC_LABEL:
                    return root
        return None
    for base in ("/media", "/run/media"):
        for dirpath, dirnames, _ in os.walk(base):
            if MSC_LABEL in dirnames:
                return os.path.join(dirpath, MSC_LABEL)
            if dirpath.count(os.sep) > 3:
                dirnames[:] = []
    return None


def do_msc(a):
    root = a.drive or find_msc_drive()
    if not root:
        sys.exit(f"USB drive '{MSC_LABEL}' not found. Check Explorer, or give --drive E:\\")
    path = os.path.join(root, MSC_FILE)
    size = a.mb * (1 << 20)
    print(f"USB drive {MSC_LABEL} = {root}. Writing {a.mb} MB to {path} ...")
    if os.path.exists(path):
        os.remove(path)
    h = hashlib.sha256()
    t0 = time.monotonic()
    with open(path, "wb", buffering=0) as f:
        for _ in range(a.mb):
            blk = os.urandom(1 << 20)
            h.update(blk)
            f.write(blk)
        os.fsync(f.fileno())
    dt = time.monotonic() - t0
    sha = h.hexdigest()
    h2 = hashlib.sha256()
    with open(path, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h2.update(blk)
    ok = h2.hexdigest() == sha and os.path.getsize(path) == size
    print(f"Write: {a.mb} MB in {dt:.2f} s = {a.mb / dt:.1f} MB/s   Read-back: {'PASS' if ok else 'FAIL'}")
    print(f"sha256: {sha}")
    print("\nNow EJECT the drive in Explorer (Safely Remove), then on the board run:")
    print(f"  sudo python3 svx_usb_test.py msc-verify {sha}")
    sys.exit(0 if ok else 1)


def do_serial(a):
    try:
        import serial
        from serial.tools import list_ports
    except ImportError:
        sys.exit("pyserial missing. Run: pip install pyserial")
    ports = list(list_ports.comports())
    is_svx = lambda port: port.vid == SVX_VID and port.pid == SVX_PID
    if a.list:
        for port in ports:
            print(f"{port.device:8} {port.description}{'   <-- SVX' if is_svx(port) else ''}")
        return
    if not a.port:
        svx = [port.device for port in ports if is_svx(port)]
        if len(svx) != 1:
            sys.exit("Board COM port not found (VID:PID 1D6B:0104). Check the J1 cable, "
                     "run 'python pc_usb_test.py --list', or give --port COMx.")
        a.port = svx[0]

    ok, nbytes = 0, 0
    with serial.serial_for_url(a.port, baudrate=115200, timeout=2.0) as s:
        time.sleep(0.2)
        s.reset_input_buffer()
        t0 = time.monotonic()
        for i in range(a.count):
            msg = os.urandom(a.size)
            s.write(msg)
            rx = s.read(len(msg))
            nbytes += len(msg)
            if rx == msg:
                ok += 1
            else:
                print(f"FAIL #{i}: sent {len(msg)} bytes, got {len(rx)} bytes"
                      f"{' (data differs)' if len(rx) == len(msg) else ''}")
                if not rx:
                    print("No reply: is 'python3 svx_usb_test.py echo' running on the board?")
                    break
        dt = time.monotonic() - t0
    rate = 2 * nbytes / dt / 1e6 if dt else 0
    print(f"{a.port}: {ok}/{a.count} packets PASS, {nbytes} bytes each way in {dt:.2f} s "
          f"({rate:.2f} MB/s total)")
    sys.exit(0 if ok == a.count else 1)


def main():
    p = argparse.ArgumentParser(description="PC side USB device-mode test for SVX-CPU-PCM5-001")
    p.add_argument("--port", help="COM port (default: auto-detect the board)")
    p.add_argument("--count", type=int, default=1000)
    p.add_argument("--size", type=int, default=512, help="bytes per packet")
    p.add_argument("--list", action="store_true")
    p.add_argument("--msc", action="store_true", help="USB drive test instead of serial")
    p.add_argument("--mb", type=int, default=32, help="--msc: MB to write (max ~60)")
    p.add_argument("--drive", help="--msc: drive root, e.g. E:\\ (default: find label SVX_TEST)")
    a = p.parse_args()
    (do_msc if a.msc else do_serial)(a)


if __name__ == "__main__":
    main()
