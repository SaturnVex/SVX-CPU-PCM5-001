#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Script: svx_usb_gadget.sh - USB CDC-ACM serial gadget on J1 (dwc2 peripheral mode).
# Usage : sudo bash svx_usb_gadget.sh start|stop     (run at boot by svx-usb-gadget.service)
# The PC sees "SVX-CPU-PCM5-001 USB test" as a COM port (board side /dev/ttyGS0) plus a
# 64 MB USB drive labelled SVX_TEST (backed by /opt/svx-usb/msc.img, created by 01_setup.sh device).
set -euo pipefail

G=/sys/kernel/config/usb_gadget/svx
IMG=/opt/svx-usb/msc.img

stop() {
    [ -d "$G" ] || return 0
    echo "" > "$G/UDC" 2>/dev/null || true
    rm -f "$G/configs/c.1/acm.usb0" "$G/configs/c.1/mass_storage.usb0"
    rmdir "$G/configs/c.1/strings/0x409" "$G/configs/c.1" 2>/dev/null || true
    rmdir "$G/functions/acm.usb0" "$G/functions/mass_storage.usb0" "$G/strings/0x409" 2>/dev/null || true
    rmdir "$G" 2>/dev/null || true
}

start() {
    modprobe libcomposite
    mountpoint -q /sys/kernel/config || mount -t configfs none /sys/kernel/config
    UDC=""
    for _ in $(seq 1 20); do               # wait up to 10 s for dwc2 to register its UDC
        UDC=$(ls /sys/class/udc 2>/dev/null | head -n1 || true)
        [ -n "$UDC" ] && break
        sleep 0.5
    done
    if [ -z "$UDC" ]; then
        echo "No USB device controller. Is dtoverlay=dwc2,dr_mode=peripheral in config.txt?" >&2
        exit 1
    fi
    stop
    mkdir -p "$G"
    cd "$G"
    echo 0x1d6b > idVendor                 # Linux Foundation
    echo 0x0104 > idProduct                # Multifunction Composite Gadget
    echo 0x0100 > bcdDevice
    echo 0x0200 > bcdUSB
    echo 0xEF > bDeviceClass               # IAD: lets Windows load its in-box usbser driver
    echo 0x02 > bDeviceSubClass
    echo 0x01 > bDeviceProtocol
    mkdir -p strings/0x409
    SN=$(tr -d '\0' < /proc/device-tree/serial-number 2>/dev/null || echo 0000)
    echo "$SN" > strings/0x409/serialnumber
    echo "SaturnVex" > strings/0x409/manufacturer
    echo "SVX-CPU-PCM5-001 USB test" > strings/0x409/product
    mkdir -p configs/c.1/strings/0x409
    echo "CDC ACM" > configs/c.1/strings/0x409/configuration
    echo 100 > configs/c.1/MaxPower
    mkdir -p functions/acm.usb0
    ln -sf "$G/functions/acm.usb0" configs/c.1/
    if [ -f "$IMG" ]; then                 # USB drive "SVX_TEST" backed by an image file
        mkdir -p functions/mass_storage.usb0
        echo 1 > functions/mass_storage.usb0/stall
        echo 1 > functions/mass_storage.usb0/lun.0/removable
        echo 0 > functions/mass_storage.usb0/lun.0/ro
        echo "$IMG" > functions/mass_storage.usb0/lun.0/file
        ln -sf "$G/functions/mass_storage.usb0" configs/c.1/
    fi
    echo "$UDC" > UDC
    echo "USB gadget active on $UDC -> /dev/ttyGS0$([ -f "$IMG" ] && echo " + USB drive $IMG")"
}

case "${1:-}" in
    start) start ;;
    stop)  stop ;;
    *) echo "Usage: $0 start|stop"; exit 1 ;;
esac
