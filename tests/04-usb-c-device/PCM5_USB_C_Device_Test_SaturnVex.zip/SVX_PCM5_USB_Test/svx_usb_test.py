#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_usb_test.py - USB 2.0 test of USB-C connector J1 on board SVX-CPU-PCM5-001 (runs on the board).

J1 D+/D- -> D2 USBLC6-2SC6 -> CM5 USB_P/USB_N (CN2 pin 5/3), DWC2 controller.
J1 is used only as a USB device: 01_setup.sh device sets dtoverlay=dwc2,dr_mode=peripheral
(no H1 jumper, J1 to PC). Host mode is not supported on J1.

  python3 svx_usb_test.py status           # controller role, gadget state
  python3 svx_usb_test.py echo             # echo /dev/ttyGS0 for pc_usb_test.py
  python3 svx_usb_test.py watch            # count cable re-plugs (enumeration)
  sudo python3 svx_usb_test.py msc-verify <sha256>   # check file the PC wrote

Power: board from DC jack U1; J1 to the PC with a standard USB cable.

Uses pySerial (BSD-3-Clause) installed from the OS repository.
"""
import argparse
import glob
import os
import re
import subprocess
import sys

USB_SYS = "/sys/bus/usb/devices"
GADGET_TTY = "/dev/ttyGS0"


def rd(path, default=""):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return default


def dwc2_root_hubs():
    """Root hubs (usbN) whose host controller is bound to the dwc2 driver."""
    hubs = []
    for bus in sorted(glob.glob(f"{USB_SYS}/usb*")):
        real = os.path.realpath(bus)
        drv = os.path.basename(os.path.realpath(os.path.join(os.path.dirname(real), "driver")))
        if drv == "dwc2":
            hubs.append(real)
    return hubs


def udcs():
    return sorted(os.listdir("/sys/class/udc")) if os.path.isdir("/sys/class/udc") else []


def do_status(_a):
    hubs, u = dwc2_root_hubs(), udcs()
    cfg = [ln.strip() for path in ("/boot/firmware/config.txt", "/boot/config.txt")
           for ln in rd(path).splitlines() if "dwc2" in ln]
    print("config.txt dwc2 lines :", "; ".join(cfg) or "none")
    if hubs:
        print("J1 USB 2.0 role       : HOST (dwc2 bus " + ", ".join(os.path.basename(h) for h in hubs) + ")"
              " -> not supported on J1. Run: sudo bash 01_setup.sh device, then reboot.")
    if u:
        for name in u:
            state = rd(f"/sys/class/udc/{name}/state", "?")
            speed = rd(f"/sys/class/udc/{name}/current_speed", "?")
            print(f"J1 USB 2.0 role       : DEVICE (UDC {name}, state={state}, speed={speed})")
        print(f"Gadget serial port    : {GADGET_TTY} {'present' if os.path.exists(GADGET_TTY) else 'MISSING'}")
    print_power()
    if not u:
        if not hubs:
            print("J1 USB 2.0 role       : not active. Run: sudo bash 01_setup.sh device, then reboot.")
        sys.exit(1)


def print_power():
    """Undervoltage flags and USB-C PD current reported by the firmware (if available)."""
    try:
        r = subprocess.run(["vcgencmd", "get_throttled"], capture_output=True, text=True, timeout=5)
        m = re.search(r"0x([0-9a-fA-F]+)", r.stdout)
        if m:
            v = int(m.group(1), 16)
            now = "UNDERVOLTAGE NOW" if v & 0x1 else "ok"
            past = "undervoltage occurred since boot" if v & 0x10000 else "no undervoltage since boot"
            print(f"Power (get_throttled) : 0x{v:x}  {now}, {past}")
    except (OSError, subprocess.SubprocessError):
        pass


def do_watch(a):
    """Count cable plug-ins: each must reach UDC state 'configured' (enumerated by the PC)."""
    import time
    u = udcs()
    if not u:
        sys.exit("No UDC: device mode not active. Run: sudo bash 01_setup.sh device, reboot.")
    path = f"/sys/class/udc/{u[0]}/state"
    last, n = rd(path), 0
    print(f"UDC {u[0]} state now: {last}")
    print(f"Unplug and re-plug the J1 cable {a.count} times (flip the plug every time). Ctrl+C to stop.")
    try:
        while n < a.count:
            s = rd(path)
            if s != last:
                if s == "configured":
                    n += 1
                print(f"{time.strftime('%H:%M:%S')}  {s:14} connects: {n}/{a.count}", flush=True)
                last = s
            time.sleep(0.05)
    except KeyboardInterrupt:
        pass
    print(f"Result: {n}/{a.count} re-connects reached 'configured' -> {'PASS' if n >= a.count else 'FAIL'}")
    sys.exit(0 if n >= a.count else 1)


def do_msc_verify(a):
    """Mount the gadget image read-only and check SVXTEST.BIN written by pc_usb_test.py --msc."""
    import hashlib
    import tempfile
    img = "/opt/svx-usb/msc.img"
    if os.geteuid() != 0:
        sys.exit("Needs root: sudo python3 svx_usb_test.py msc-verify <sha256>")
    if not os.path.exists(img):
        sys.exit(f"{img} not found. Run: sudo bash 01_setup.sh device")
    mnt = tempfile.mkdtemp(prefix="svxmsc")
    r = subprocess.run(["mount", "-o", "ro,loop", img, mnt], capture_output=True, text=True)
    if r.returncode:
        os.rmdir(mnt)
        sys.exit(f"mount failed: {r.stderr.strip()}")
    try:
        names = {n.upper(): n for n in os.listdir(mnt)}
        if "SVXTEST.BIN" not in names:
            sys.exit("SVXTEST.BIN not in the image. Run pc_usb_test.py --msc on the PC first.")
        h = hashlib.sha256()
        with open(os.path.join(mnt, names["SVXTEST.BIN"]), "rb") as f:
            for blk in iter(lambda: f.read(1 << 20), b""):
                h.update(blk)
        got = h.hexdigest()
    finally:
        subprocess.run(["umount", mnt])
        os.rmdir(mnt)
    print(f"Board sha256: {got}")
    if a.sha:
        ok = got == a.sha.lower()
        print(f"PC    sha256: {a.sha.lower()}\nResult: {'PASS' if ok else 'FAIL'} (data written by the PC over USB)")
        sys.exit(0 if ok else 1)


def do_echo(_a):
    try:
        import serial
    except ImportError:
        sys.exit("python3-serial not found. Run: sudo bash 01_setup.sh device")
    if not os.path.exists(GADGET_TTY):
        sys.exit(f"{GADGET_TTY} not found. Run: sudo bash 01_setup.sh device, reboot, "
                 "connect J1 to the PC. Check: systemctl status svx-usb-gadget")
    print(f"Echo on {GADGET_TTY} (USB CDC-ACM gadget on J1). Ctrl+C to stop.")
    total = 0
    with serial.Serial(GADGET_TTY, timeout=0.2) as s:
        try:
            while True:
                data = s.read(s.in_waiting or 1)
                if data:
                    s.write(data)
                    total += len(data)
                    print(f"\rRX/TX bytes: {total}", end="", flush=True)
        except KeyboardInterrupt:
            print(f"\nStopped. Echoed {total} bytes.")
        except serial.SerialException as e:
            print(f"\nPort closed ({e}). Echoed {total} bytes. Is the USB cable still connected?")


def main():
    p = argparse.ArgumentParser(description="SVX-CPU-PCM5-001 USB-C J1 (USB 2.0) test")
    p.add_argument("mode", choices=["status", "echo", "watch", "msc-verify"])
    p.add_argument("sha", nargs="?", help="msc-verify: sha256 printed by pc_usb_test.py --msc")
    p.add_argument("--count", type=int, default=10, help="watch: re-connects to count")
    a = p.parse_args()
    {"status": do_status, "echo": do_echo, "watch": do_watch,
     "msc-verify": do_msc_verify}[a.mode](a)


if __name__ == "__main__":
    main()
