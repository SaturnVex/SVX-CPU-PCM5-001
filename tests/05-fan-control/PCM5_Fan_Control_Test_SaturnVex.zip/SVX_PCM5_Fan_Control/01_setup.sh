#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 01_setup.sh - install the CPU temperature fan control as a systemd service.
# Usage : sudo bash 01_setup.sh [options passed to svx_fan_control.py]
#   e.g.  sudo bash 01_setup.sh                          # GPIO45 (CN1 pin 19 Fan_PWM), ON >40 C, OFF <35 C
#         sudo bash 01_setup.sh --gpio 24 --on 50 --off 42
#         sudo bash 01_setup.sh --uninstall
set -euo pipefail

DIR=/opt/svx-fan
UNIT=/etc/systemd/system/svx-fan.service
SRC="$(cd "$(dirname "$0")" && pwd)"

if [ "$(id -u)" -ne 0 ]; then echo "Run with sudo:  sudo bash $0 $*"; exit 1; fi

if [ "${1:-}" = "--uninstall" ]; then
    systemctl disable --now svx-fan.service 2>/dev/null || true
    rm -f "$UNIT"; rm -rf "$DIR"; systemctl daemon-reload
    echo "svx-fan removed."; exit 0
fi

echo "==> [1/4] Installing packages"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3-libgpiod gpiod raspi-utils

echo "==> [2/4] Copying program to $DIR"
install -d "$DIR"
install -m 755 "$SRC/svx_fan_control.py" "$DIR/svx_fan_control.py"
sed -i 's/\r$//' "$DIR/svx_fan_control.py"
python3 "$DIR/svx_fan_control.py" "$@" --once   # validates options + reads temperature

echo "==> [3/4] Writing $UNIT"
ARGS="$*"
cat > "$UNIT" <<EOF
[Unit]
Description=SVX CPU temperature fan control (svx_fan_control.py $ARGS)
After=multi-user.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 -u $DIR/svx_fan_control.py $ARGS
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

echo "==> [4/4] Enabling and starting service"
systemctl daemon-reload
systemctl enable --now svx-fan.service
sleep 1
systemctl --no-pager --lines=5 status svx-fan.service || true

echo
echo "Live log : journalctl -u svx-fan -f"
echo "Stop     : sudo systemctl stop svx-fan      Remove: sudo bash $0 --uninstall"
