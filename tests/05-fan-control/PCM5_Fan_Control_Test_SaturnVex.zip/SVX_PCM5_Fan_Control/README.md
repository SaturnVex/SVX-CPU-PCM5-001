# CPU Fan Control Test

**Package:** `SVX_PCM5_Fan_Control` · **Board:** `SVX-CPU-PCM5-001` · **Module:** Raspberry Pi CM5 (tested with CM5 Lite 8 GB, SC1568) · **OS:** Raspberry Pi OS 64-bit

Fan connector FAN1 switched by the CM5 Fan_PWM signal (GPIO45): manual check, temperature control with hysteresis (ON > 40 °C, OFF < 35 °C) and installation as a systemd service.

## Hardware
- 5 V two-wire fan on FAN1 (pin 1 = +5 V, pin 2 = fan −)
- 2.2 kΩ pull-up from FAN_PWM to +3.3 V on the board

## Quick start (on the board)
```bash
python3 svx_fan_control.py --once        # print the CPU temperature
pinctrl set 45 op dl                     # fan ON  (active-low)
pinctrl set 45 op dh                     # fan OFF
python3 svx_fan_control.py               # automatic control, Ctrl+C to stop
sudo bash 01_setup.sh                    # install the svx-fan service
```

Full setup, connections and acceptance criteria: see the PDF test guide `SaturnVex_PCM5_Fan_Control_Test_Guide_EN.pdf`.
Copy this folder to the board (for example with `scp -r`) and run the scripts there; the guide shows the complete Windows PowerShell commands.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
