#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_fan_control.py - CPU temperature fan control for board SVX-CPU-PCM5-001.

Reads the SoC temperature and switches a fan through one GPIO with hysteresis:
    temp >  ON  threshold (default 40 C)  -> fan ON
    temp <  OFF threshold (default 35 C)  -> fan OFF
    in between                            -> keep current state

  python3 svx_fan_control.py                      # GPIO45 (CM5 CN1 pin 19 Fan_PWM), 40/35 C
  python3 svx_fan_control.py --gpio 24 --on 50 --off 42 --interval 1
  python3 svx_fan_control.py --dry-run            # no GPIO, only print decisions
  python3 svx_fan_control.py --once               # print temperature and exit

Options: --active-high  GPIO HIGH = fan ON (default is active-low: on board
                        SVX-CPU-PCM5-001 the CM5 open-drain Fan_PWM inverts,
                        GPIO45 LOW = fan ON, HIGH = fan OFF)
         --exit-state   fan state when the program stops: on (default, fail-safe) | off
Fan_PWM (RP1 GPIO45) must not be claimed by the kernel fan driver: remove
dtparam=cooling_fan=on from config.txt when using this program.
Uses libgpiod Python bindings (LGPL-2.1-or-later) installed from the OS repository.
"""
import argparse
import glob
import signal
import sys
import time

TEMP_PATH = "/sys/class/thermal/thermal_zone0/temp"


def read_temp_c():
    """SoC temperature in degrees C (sysfs value is millidegrees)."""
    with open(TEMP_PATH) as f:
        return int(f.read().strip()) / 1000.0


def find_chip(gpiod):
    """Return the RP1 GPIO chip path (label 'pinctrl-rp1')."""
    for path in sorted(glob.glob("/dev/gpiochip*")):
        try:
            with gpiod.Chip(path) as chip:
                info = chip.get_info()
                if "rp1" in info.label and info.num_lines >= 28:
                    return path
        except OSError:
            continue
    sys.exit("RP1 GPIO chip not found (check: gpiodetect)")


class Fan:
    """Fan switch on one GPIO; with dry_run only prints."""

    def __init__(self, gpio, active_low, dry_run):
        self.gpio, self.active_low, self.dry_run = gpio, active_low, dry_run
        self.req = None
        if dry_run:
            return
        try:
            import gpiod
            from gpiod.line import Direction, Value
        except ImportError:
            sys.exit("python3-libgpiod (v2) not found. Run: sudo bash 01_setup.sh")
        self._Value = Value
        try:
            self.req = gpiod.request_lines(
                find_chip(gpiod), consumer="svx-fan",
                config={gpio: gpiod.LineSettings(direction=Direction.OUTPUT,
                                                 output_value=self._level(False))})
        except OSError as e:
            hint = (" GPIO45 is taken by the kernel fan driver when "
                    "dtparam=cooling_fan=on is in config.txt: remove it and reboot."
                    if gpio == 45 else "")
            sys.exit(f"GPIO{gpio} request failed: {e}. Pin may be used by another "
                     f"function or program. Check: pinctrl get {gpio}.{hint}")

    def _level(self, on):
        Value = self._Value
        high = on != self.active_low
        return Value.ACTIVE if high else Value.INACTIVE

    def set(self, on):
        if self.req is not None:
            self.req.set_value(self.gpio, self._level(on))

    def close(self):
        if self.req is not None:
            self.req.release()
            self.req = None


def main():
    p = argparse.ArgumentParser(description="SVX-CPU-PCM5-001 CPU temperature fan control")
    p.add_argument("--gpio", type=int, default=45,
                   help="fan control GPIO (default 45 = CM5 CN1 pin 19 Fan_PWM)")
    p.add_argument("--on", type=float, default=40.0, help="turn fan ON above this temp, C")
    p.add_argument("--off", type=float, default=35.0, help="turn fan OFF below this temp, C")
    p.add_argument("--interval", type=float, default=2.0, help="seconds between reads")
    pol = p.add_mutually_exclusive_group()
    pol.add_argument("--active-low", dest="active_low", action="store_true", default=True,
                     help="GPIO LOW = fan ON (default)")
    pol.add_argument("--active-high", dest="active_low", action="store_false",
                     help="GPIO HIGH = fan ON")
    p.add_argument("--exit-state", choices=["on", "off"], default="on")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--once", action="store_true")
    a = p.parse_args()

    if a.off >= a.on:
        sys.exit(f"--off ({a.off}) must be lower than --on ({a.on})")
    try:
        temp = read_temp_c()
    except OSError as e:
        sys.exit(f"Cannot read {TEMP_PATH}: {e}")
    if a.once:
        print(f"CPU temp: {temp:.1f} C")
        return

    # SIGTERM (systemctl stop) -> same clean exit path as Ctrl+C
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt))

    fan = Fan(a.gpio, a.active_low, a.dry_run)
    on = temp > a.on          # start state: ON only if already hot
    fan.set(on)
    print(f"Fan control GPIO{a.gpio}{' active-low' if a.active_low else ' active-high'}"
          f"{' [dry-run]' if a.dry_run else ''}: ON > {a.on:g} C, OFF < {a.off:g} C, "
          f"every {a.interval:g} s", flush=True)
    print(f"{temp:5.1f} C  fan {'ON' if on else 'OFF'} (start)", flush=True)

    try:
        while True:
            time.sleep(a.interval)
            try:
                temp = read_temp_c()
            except OSError as e:
                print(f"Temp read error: {e} -> fan ON (fail-safe)", flush=True)
                if not on:
                    on = True
                    fan.set(True)
                continue
            new = True if temp > a.on else False if temp < a.off else on
            if new != on:
                on = new
                fan.set(on)
                print(f"\r{temp:5.1f} C  fan {'ON' if on else 'OFF'}", flush=True)
            elif sys.stdout.isatty():
                print(f"\r{temp:5.1f} C  fan {'ON ' if on else 'OFF'}", end="", flush=True)
    except KeyboardInterrupt:
        fan.set(a.exit_state == "on")
        print(f"\nStopped, fan left {a.exit_state.upper()}.", flush=True)
    finally:
        fan.close()


if __name__ == "__main__":
    main()
