#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 01_setup.sh - install build tools and enable I2C1 (400 kHz) on H3.
# Usage : sudo bash 01_setup.sh          then: sudo reboot
#
# I2C1 -> /dev/i2c-1 : SDA = GPIO2 = H3 pin 19, SCL = GPIO3 = H3 pin 17
set -euo pipefail

CFG=/boot/firmware/config.txt
[ -f "$CFG" ] || CFG=/boot/config.txt
BEGIN="# >>> SVX bmm350-i2c (01_setup.sh) >>>"
END="# <<< SVX bmm350-i2c (01_setup.sh) <<<"

if [ "$(id -u)" -ne 0 ]; then echo "Run with sudo:  sudo bash $0"; exit 1; fi

echo "==> [1/3] Installing build tools and i2c-tools"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y build-essential i2c-tools

echo "==> [2/3] Enabling I2C1 at 400 kHz in $CFG"
[ -f "${CFG}.orig" ] || cp "$CFG" "${CFG}.orig"
cp "$CFG" "${CFG}.$(date +%Y%m%d-%H%M%S).bak"
sed -i 's/\r$//' "$CFG"
sed -i '/^# >>> SVX bmm350-i2c/,/^# <<< SVX bmm350-i2c/d' "$CFG"
sed -i -e :a -e '/^\n*$/{$d;N;ba' -e '}' "$CFG"
{
    echo ""
    echo "$BEGIN"
    echo "[all]"
    echo "dtparam=i2c_arm=on,i2c_arm_baudrate=400000"
    echo "$END"
} >> "$CFG"
grep -n 'i2c_arm' "$CFG" || true

echo "==> [3/3] Adding user to i2c group"
U="${SUDO_USER:-$(logname 2>/dev/null || echo pi)}"
if getent group i2c >/dev/null; then usermod -aG i2c "$U"; fi

echo
echo "Now:  sudo reboot"
echo "Then: i2cdetect -y 1     (BMM350 appears at 14, or 15 if ADSEL is high)"
echo "      make && ./svx_bmm350_polling"
