#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 02_check.sh - check I2C1 and the BMM350 chip ID without building the program.
# Usage : bash 02_check.sh [bus]      (default bus 1)
BUS="${1:-1}"

echo "===== I2C1 configuration ====="
grep -n 'i2c_arm' /boot/firmware/config.txt 2>/dev/null
ls -l "/dev/i2c-$BUS" 2>/dev/null || { echo "/dev/i2c-$BUS missing -> sudo bash 01_setup.sh && sudo reboot"; exit 1; }
pinctrl get 2-3 2>/dev/null          # expect GPIO2 = SDA1, GPIO3 = SCL1

echo; echo "===== Bus scan (BMM350 = 14 with ADSEL to GND, 15 with ADSEL to VDDIO) ====="
i2cdetect -y "$BUS"

echo; echo "===== Chip ID (register 0x00; BMM350 sends 2 dummy bytes first) ====="
FOUND=0
for A in 0x14 0x15; do
    R=$(i2ctransfer -y "$BUS" w1@$A 0x00 r3 2>/dev/null)
    if [ -n "$R" ]; then
        ID=$(echo "$R" | awk '{print $3}')
        echo "addr $A -> bytes: $R  -> chip ID $ID"
        if [ "$ID" = "0x33" ]; then echo "PASS: BMM350 found at $A"; FOUND=1; fi
    else
        echo "addr $A -> no answer"
    fi
done

[ "$FOUND" = 1 ] && exit 0
echo
echo "FAIL: BMM350 not found. Check wiring (SDA=H3-19, SCL=H3-17, GND=H3-23),"
echo "      sensor power, and that SDA/SCL pull-ups go to 3.3 V."
exit 1
