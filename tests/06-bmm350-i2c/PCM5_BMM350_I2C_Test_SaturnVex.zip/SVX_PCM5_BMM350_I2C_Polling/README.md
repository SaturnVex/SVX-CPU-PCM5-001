# BMM350 Magnetometer (I²C) Test

**Package:** `SVX_PCM5_BMM350_I2C_Polling` · **Board:** `SVX-CPU-PCM5-001` · **Module:** Raspberry Pi CM5 (tested with CM5 Lite 8 GB, SC1568) · **OS:** Raspberry Pi OS 64-bit

Bosch BMM350 3-axis magnetometer on I²C1 of header H3, read with the official Bosch SensorAPI by data-ready polling; compensated X/Y/Z field, magnitude and temperature as CSV.

## Hardware
- BMM350 sensor board on H3: pin 19 SDA (GPIO2), pin 17 SCL (GPIO3), pin 21 +3.3 V, pin 23 GND
- I²C address 0x14 (ADSEL = GND)

## Quick start (on the board)
```bash
sudo bash 01_setup.sh && sudo reboot
bash 02_check.sh                          # PASS: BMM350 found at 0x14
make
./svx_bmm350_polling -n 50                # 50 samples at 25 Hz
```

The Bosch BMM350 SensorAPI v1.10.0 is included unmodified in `third_party/BMM350_SensorAPI/` (BSD-3-Clause).

Full setup, connections and acceptance criteria: see the PDF test guide `SaturnVex_PCM5_BMM350_I2C_Test_Guide_EN.pdf`.
Copy this folder to the board (for example with `scp -r`) and run the scripts there; the guide shows the complete Windows PowerShell commands.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`. The Bosch Sensortec BMM350 SensorAPI in `third_party/` keeps its own BSD-3-Clause license.
