/*
 * SPDX-License-Identifier: BSD-3-Clause
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 *
 * svx_bmm350_polling.c - read BMM350 magnetometer over I2C by polling the
 * data-ready status bit. Board SVX-CPU-PCM5-001, header H3:
 *   pin 19 = GPIO2 = SDA1, pin 17 = GPIO3 = SCL1, pin 21 = +3.3 V, pin 23 = GND
 *
 * Usage: ./svx_bmm350_polling [-b bus] [-a addr] [-r odr_hz] [-n samples] [-p poll_us]
 *   -b  I2C bus number              (default 1  -> /dev/i2c-1)
 *   -a  7-bit address 0x14 or 0x15  (default 0x14: ADSEL tied to GND on the sensor board)
 *       If no BMM350 answers at the given address, the other address is tried.
 *   -r  output data rate in Hz: 400 200 100 50 25 12.5 6.25 3.125 1.5625 (default 25)
 *   -n  number of samples, 0 = run until Ctrl+C (default 0)
 *   -p  status polling interval in microseconds (default 1000)
 * Output: CSV  time_ms,x_uT,y_uT,z_uT,|B|_uT,temp_C
 *
 * Uses the Bosch Sensortec BMM350 SensorAPI (BSD-3-Clause), see third_party/.
 */
#include <errno.h>
#include <math.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "bmm350.h"
#include "svx_linux_i2c.h"

static volatile sig_atomic_t g_stop = 0;

static void on_signal(int sig)
{
    (void)sig;
    g_stop = 1;
}

static double now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1.0e6;
}

static const char *rslt_text(int8_t rslt)
{
    switch (rslt) {
    case BMM350_OK:                    return "OK";
    case BMM350_E_NULL_PTR:            return "null pointer";
    case BMM350_E_COM_FAIL:            return "I2C communication failed";
    case BMM350_E_DEV_NOT_FOUND:       return "device not found (wrong chip ID)";
    case BMM350_E_INVALID_CONFIG:      return "invalid configuration";
    case BMM350_E_OTP_BOOT:            return "OTP boot error";
    case BMM350_E_ALL_AXIS_DISABLED:   return "all axes disabled";
    case BMM350_E_PMU_CMD_VALUE:       return "invalid PMU command";
    default:                           return "error";
    }
}

/* Exit with a message when a SensorAPI call fails. */
static void check(const char *what, int8_t rslt, struct svx_i2c *bus)
{
    if (rslt != BMM350_OK) {
        fprintf(stderr, "ERROR %s: %d (%s)\n", what, rslt, rslt_text(rslt));
        if (rslt == BMM350_E_COM_FAIL || rslt == BMM350_E_DEV_NOT_FOUND) {
            fprintf(stderr, "Check wiring, pull-ups and address: i2cdetect -y 1 must show 14 or 15.\n");
        }
        svx_i2c_close(bus);
        exit(EXIT_FAILURE);
    }
}

/*
 * Read the chip ID directly (register 0x00). BMM350 returns 2 dummy bytes
 * before the data, so 3 bytes are read and the third one is the chip ID.
 * Returns 1 = BMM350 found, 0 = device answered with another ID, -1 = no answer.
 */
static int probe_chip_id(struct svx_i2c *bus, uint8_t *id_out)
{
    uint8_t buf[3] = { 0 };

    if (svx_i2c_read(BMM350_REG_CHIP_ID, buf, sizeof(buf), bus) != 0) {
        return -1;
    }
    *id_out = buf[2];
    return (buf[2] == BMM350_CHIP_ID) ? 1 : 0;
}

struct odr_map {
    double hz;
    enum bmm350_data_rates odr;
    enum bmm350_performance_parameters avg;
};

/* Averaging chosen per ODR to stay inside the datasheet ODR/averaging limits. */
static const struct odr_map ODR_TABLE[] = {
    { 400.0,  BMM350_DATA_RATE_400HZ,    BMM350_NO_AVERAGING },
    { 200.0,  BMM350_DATA_RATE_200HZ,    BMM350_AVERAGING_2  },
    { 100.0,  BMM350_DATA_RATE_100HZ,    BMM350_AVERAGING_4  },
    { 50.0,   BMM350_DATA_RATE_50HZ,     BMM350_AVERAGING_8  },
    { 25.0,   BMM350_DATA_RATE_25HZ,     BMM350_AVERAGING_8  },
    { 12.5,   BMM350_DATA_RATE_12_5HZ,   BMM350_AVERAGING_8  },
    { 6.25,   BMM350_DATA_RATE_6_25HZ,   BMM350_AVERAGING_8  },
    { 3.125,  BMM350_DATA_RATE_3_125HZ,  BMM350_AVERAGING_8  },
    { 1.5625, BMM350_DATA_RATE_1_5625HZ, BMM350_AVERAGING_8  },
};

static void usage(const char *prog)
{
    fprintf(stderr, "Usage: %s [-b bus] [-a 0x14|0x15] [-r odr_hz] [-n samples] [-p poll_us]\n", prog);
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    int bus_num = 1;
    unsigned long addr = BMM350_I2C_ADSEL_SET_LOW;
    double odr_hz = 25.0;
    long samples = 0;
    long poll_us = 1000;
    const struct odr_map *odr = NULL;
    int opt;

    while ((opt = getopt(argc, argv, "b:a:r:n:p:h")) != -1) {
        switch (opt) {
        case 'b': bus_num = atoi(optarg); break;
        case 'a': addr = strtoul(optarg, NULL, 0); break;
        case 'r': odr_hz = atof(optarg); break;
        case 'n': samples = atol(optarg); break;
        case 'p': poll_us = atol(optarg); break;
        default:  usage(argv[0]);
        }
    }
    if (addr != BMM350_I2C_ADSEL_SET_LOW && addr != BMM350_I2C_ADSEL_SET_HIGH) {
        fprintf(stderr, "Address must be 0x14 or 0x15\n");
        return EXIT_FAILURE;
    }
    for (size_t i = 0; i < sizeof(ODR_TABLE) / sizeof(ODR_TABLE[0]); i++) {
        if (fabs(ODR_TABLE[i].hz - odr_hz) < 1e-6) {
            odr = &ODR_TABLE[i];
        }
    }
    if (odr == NULL) {
        fprintf(stderr, "ODR must be one of 400 200 100 50 25 12.5 6.25 3.125 1.5625\n");
        return EXIT_FAILURE;
    }
    if (poll_us < 100) {
        poll_us = 100;
    }

    struct svx_i2c bus = { .fd = -1, .addr = 0 };
    if (svx_i2c_open(&bus, bus_num, (uint8_t)addr) != 0) {
        fprintf(stderr, "Cannot open /dev/i2c-%d: %s\nRun: sudo bash 01_setup.sh, then reboot.\n",
                bus_num, strerror(errno));
        return EXIT_FAILURE;
    }

    /* Probe the requested address first, then the alternative one */
    {
        uint8_t id = 0;
        int found = probe_chip_id(&bus, &id);

        if (found != 1) {
            uint8_t other = (bus.addr == BMM350_I2C_ADSEL_SET_LOW) ? BMM350_I2C_ADSEL_SET_HIGH
                                                                   : BMM350_I2C_ADSEL_SET_LOW;
            uint8_t id2 = 0;
            if (found == 0) {
                fprintf(stderr, "Device at 0x%02X answered with ID 0x%02X (not BMM350 0x%02X)\n",
                        bus.addr, id, BMM350_CHIP_ID);
            } else {
                fprintf(stderr, "No answer at 0x%02X, trying 0x%02X...\n", bus.addr, other);
            }
            bus.addr = other;
            if (probe_chip_id(&bus, &id2) == 1) {
                fprintf(stderr, "BMM350 found at 0x%02X (check ADSEL wiring / -a option)\n", other);
                addr = other;
            } else {
                fprintf(stderr,
                        "ERROR: no BMM350 on /dev/i2c-%d at 0x14 or 0x15.\n"
                        "  - i2cdetect -y %d must show 14 or 15\n"
                        "  - wiring: SDA=H3 pin 19, SCL=H3 pin 17, GND=H3 pin 23\n"
                        "  - pull-ups on SDA/SCL must go to a 3.3 V VDDIO (1.8 V needs a level shifter)\n",
                        bus_num, bus_num);
                svx_i2c_close(&bus);
                return EXIT_FAILURE;
            }
        }
    }

    /* Hook the Linux transport into the SensorAPI */
    struct bmm350_dev dev;
    memset(&dev, 0, sizeof(dev));
    dev.intf_ptr = &bus;
    dev.read     = svx_i2c_read;
    dev.write    = svx_i2c_write;
    dev.delay_us = svx_delay_us;

    struct bmm350_version ver;
    bmm350_api_version(&ver);
    fprintf(stderr, "SVX-CPU-PCM5-001 BMM350 polling | SensorAPI v%u.%u.%u | /dev/i2c-%d addr 0x%02lX\n",
            ver.major, ver.minor, ver.bugfix, bus_num, addr);

    check("bmm350_init", bmm350_init(&dev), &bus);
    fprintf(stderr, "Chip ID: 0x%02X (expected 0x%02X)\n", dev.chip_id, BMM350_CHIP_ID);

    /* Data-ready flag in INT_STATUS is used for polling; the INT pin is not used */
    check("configure_interrupt",
          bmm350_configure_interrupt(BMM350_PULSED, BMM350_ACTIVE_HIGH, BMM350_INTR_PUSH_PULL,
                                     BMM350_UNMAP_FROM_PIN, &dev), &bus);
    check("enable_interrupt", bmm350_enable_interrupt(BMM350_ENABLE_INTERRUPT, &dev), &bus);
    check("set_odr_performance", bmm350_set_odr_performance(odr->odr, odr->avg, &dev), &bus);
    check("enable_axes", bmm350_enable_axes(BMM350_X_EN, BMM350_Y_EN, BMM350_Z_EN, &dev), &bus);
    check("set_powermode", bmm350_set_powermode(BMM350_NORMAL_MODE, &dev), &bus);

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    fprintf(stderr, "Normal mode, ODR %g Hz, polling every %ld us. Ctrl+C to stop.\n", odr->hz, poll_us);
    printf("time_ms,x_uT,y_uT,z_uT,|B|_uT,temp_C\n");
    fflush(stdout);

    const double t0 = now_ms();
    long count = 0;
    long comm_errors = 0;

    while (!g_stop && (samples == 0 || count < samples)) {
        uint8_t drdy = 0;
        int8_t rslt = bmm350_get_interrupt_status(&drdy, &dev);

        if (rslt == BMM350_OK && drdy) {
            struct bmm350_mag_temp_data d;
            rslt = bmm350_get_compensated_mag_xyz_temp_data(&d, &dev);
            if (rslt == BMM350_OK) {
                double b = sqrt((double)d.x * d.x + (double)d.y * d.y + (double)d.z * d.z);
                printf("%.1f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
                       now_ms() - t0, d.x, d.y, d.z, b, d.temperature);
                fflush(stdout);
                count++;
                continue;
            }
        }
        if (rslt != BMM350_OK && ++comm_errors >= 10) {
            fprintf(stderr, "ERROR: %ld consecutive bus errors (%s)\n", comm_errors, rslt_text(rslt));
            break;
        }
        if (rslt == BMM350_OK) {
            comm_errors = 0;
        }
        svx_delay_us((uint32_t)poll_us, NULL);
    }

    double elapsed_s = (now_ms() - t0) / 1000.0;
    fprintf(stderr, "\n%ld samples in %.2f s (%.2f Hz measured)\n",
            count, elapsed_s, elapsed_s > 0 ? count / elapsed_s : 0.0);

    bmm350_set_powermode(BMM350_SUSPEND_MODE, &dev);
    svx_i2c_close(&bus);
    return (comm_errors >= 10) ? EXIT_FAILURE : EXIT_SUCCESS;
}
