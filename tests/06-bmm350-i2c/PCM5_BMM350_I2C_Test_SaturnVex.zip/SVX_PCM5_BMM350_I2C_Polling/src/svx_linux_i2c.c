/*
 * SPDX-License-Identifier: BSD-3-Clause
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 *
 * svx_linux_i2c.c - Linux i2c-dev transport for the Bosch BMM350 SensorAPI.
 * A register read is one combined transfer (write register address, repeated
 * START, read N bytes). The SensorAPI itself requests and strips the 2 dummy
 * bytes that BMM350 returns, so this layer passes data through unchanged.
 */
#include "svx_linux_i2c.h"

#include <errno.h>
#include <fcntl.h>
#include <linux/i2c.h>
#include <linux/i2c-dev.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>

#define SVX_I2C_MAX_WRITE 64u

int svx_i2c_open(struct svx_i2c *bus, int bus_num, uint8_t addr)
{
    char path[32];
    unsigned long funcs = 0;

    snprintf(path, sizeof(path), "/dev/i2c-%d", bus_num);
    bus->addr = addr;
    bus->fd = open(path, O_RDWR);
    if (bus->fd < 0) {
        return -1;
    }
    if (ioctl(bus->fd, I2C_FUNCS, &funcs) < 0 || !(funcs & I2C_FUNC_I2C)) {
        close(bus->fd);
        bus->fd = -1;
        errno = EOPNOTSUPP;
        return -1;
    }
    return 0;
}

void svx_i2c_close(struct svx_i2c *bus)
{
    if (bus->fd >= 0) {
        close(bus->fd);
        bus->fd = -1;
    }
}

int8_t svx_i2c_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t len, void *intf_ptr)
{
    struct svx_i2c *bus = (struct svx_i2c *)intf_ptr;
    struct i2c_msg msgs[2];
    struct i2c_rdwr_ioctl_data xfer;

    if (bus == NULL || reg_data == NULL || len == 0 || len > 0xFFFFu) {
        return -1;
    }
    msgs[0].addr  = bus->addr;
    msgs[0].flags = 0;
    msgs[0].len   = 1;
    msgs[0].buf   = &reg_addr;
    msgs[1].addr  = bus->addr;
    msgs[1].flags = I2C_M_RD;
    msgs[1].len   = (uint16_t)len;
    msgs[1].buf   = reg_data;
    xfer.msgs  = msgs;
    xfer.nmsgs = 2;

    return (ioctl(bus->fd, I2C_RDWR, &xfer) == 2) ? 0 : -1;
}

int8_t svx_i2c_write(uint8_t reg_addr, const uint8_t *reg_data, uint32_t len, void *intf_ptr)
{
    struct svx_i2c *bus = (struct svx_i2c *)intf_ptr;
    uint8_t buf[1 + SVX_I2C_MAX_WRITE];
    struct i2c_msg msg;
    struct i2c_rdwr_ioctl_data xfer;

    if (bus == NULL || (len > 0 && reg_data == NULL) || len > SVX_I2C_MAX_WRITE) {
        return -1;
    }
    buf[0] = reg_addr;
    if (len > 0) {
        memcpy(&buf[1], reg_data, len);
    }
    msg.addr  = bus->addr;
    msg.flags = 0;
    msg.len   = (uint16_t)(len + 1);
    msg.buf   = buf;
    xfer.msgs  = &msg;
    xfer.nmsgs = 1;

    return (ioctl(bus->fd, I2C_RDWR, &xfer) == 1) ? 0 : -1;
}

void svx_delay_us(uint32_t period_us, void *intf_ptr)
{
    struct timespec ts;
    (void)intf_ptr;

    ts.tv_sec  = (time_t)(period_us / 1000000u);
    ts.tv_nsec = (long)(period_us % 1000000u) * 1000L;
    while (nanosleep(&ts, &ts) != 0 && errno == EINTR) {
        /* continue the remaining delay after a signal */
    }
}
