/*
 * SPDX-License-Identifier: BSD-3-Clause
 * Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
 *
 * svx_linux_i2c.h - Linux i2c-dev transport for the Bosch BMM350 SensorAPI
 *                   (board SVX-CPU-PCM5-001, header H3, I2C1).
 */
#ifndef SVX_LINUX_I2C_H
#define SVX_LINUX_I2C_H

#include <stdint.h>

struct svx_i2c {
    int     fd;      /* file descriptor of /dev/i2c-N */
    uint8_t addr;    /* 7-bit device address          */
};

/* Open /dev/i2c-<bus> for device <addr>. Returns 0 on success, -1 on error (errno set). */
int  svx_i2c_open(struct svx_i2c *bus, int bus_num, uint8_t addr);
void svx_i2c_close(struct svx_i2c *bus);

/* Callbacks matching bmm350_read_fptr_t / bmm350_write_fptr_t / bmm350_delay_us_fptr_t.
 * intf_ptr must point to an opened struct svx_i2c. Return 0 on success, -1 on bus error. */
int8_t svx_i2c_read(uint8_t reg_addr, uint8_t *reg_data, uint32_t len, void *intf_ptr);
int8_t svx_i2c_write(uint8_t reg_addr, const uint8_t *reg_data, uint32_t len, void *intf_ptr);
void   svx_delay_us(uint32_t period_us, void *intf_ptr);

#endif /* SVX_LINUX_I2C_H */
