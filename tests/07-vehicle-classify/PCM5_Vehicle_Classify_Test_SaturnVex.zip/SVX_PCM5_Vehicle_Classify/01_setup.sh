#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# Board : SVX-CPU-PCM5-001 (Raspberry Pi CM5 carrier)
# Script: 01_setup.sh - install packages and download the AI models for vehicle classification.
# Usage : sudo bash 01_setup.sh
# Needs : camera already configured with SVX_PCM5_MIPI_Camera_Test (02_config_camera.sh), Internet.
set -e
[ "$(id -u)" = 0 ] || { echo "Run with sudo: sudo bash 01_setup.sh"; exit 1; }
cd "$(dirname "$(readlink -f "$0")")"
OWNER="${SUDO_USER:-$(stat -c %U .)}"

echo "===== 1/4 Packages (Raspberry Pi OS repository) ====="
apt-get update
apt-get install -y python3-opencv python3-numpy python3-picamera2 python3-venv python3-pip curl \
    python3-libgpiod gpiod   # libgpiod: fan control on GPIO45

echo; echo "===== 2/4 onnxruntime in .venv (fast inference engine, MIT license) ====="
# --system-site-packages: the venv still uses picamera2 / OpenCV / NumPy from the OS.
sudo -u "$OWNER" python3 -m venv --system-site-packages .venv
sudo -u "$OWNER" .venv/bin/pip install --disable-pip-version-check -q onnxruntime
chmod +x run.sh

echo; echo "===== 3/4 Models (official releases, Apache-2.0, see NOTICE.txt) ====="
mkdir -p models
YOLOX=https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0
ZOO=https://github.com/opencv/opencv_zoo/raw/main/models/image_classification_mobilenet
while read -r SHA FILE URL; do
    if [ -f "models/$FILE" ] && echo "$SHA  models/$FILE" | sha256sum -c --quiet 2>/dev/null; then
        echo "ok        $FILE (already present)"
        continue
    fi
    echo "download  $FILE"
    curl -fL --retry 3 -o "models/$FILE.part" "$URL/$FILE"
    if echo "$SHA  models/$FILE.part" | sha256sum -c --quiet; then
        mv "models/$FILE.part" "models/$FILE"
    else
        rm -f "models/$FILE.part"; echo "FAIL: checksum of $FILE"; exit 1
    fi
done <<EOF
c789161ed43c8269fcd4e67c67eeeb4e80c622da2eb296a20bc6007bd18a0b7d yolox_nano.onnx $YOLOX
427cc366d34e27ff7a03e2899b5e3671425c262ea2291f88bb942bc1cc70b0f7 yolox_tiny.onnx $YOLOX
c5c2d13e59ae883e6af3b45daea64af4833a4951c92d116ec270d9ddbe998063 yolox_s.onnx $YOLOX
c0c3f76d93fa3fd6580652a45618618a220fced18babf65774ed169de0432ad5 image_classification_mobilenetv2_2022apr.onnx $ZOO
EOF
chown -R "$OWNER": models
usermod -aG video,gpio "$OWNER" || true

echo; echo "===== 4/4 Check ====="
.venv/bin/python3 -c "import cv2, numpy, picamera2, gpiod, onnxruntime as o; print('OpenCV', cv2.__version__, '| NumPy', numpy.__version__, '| onnxruntime', o.__version__, '| gpiod ok')"
if grep -qsE '^[[:space:]]*dtparam=cooling_fan=on' /boot/firmware/config.txt; then
    echo "WARN: dtparam=cooling_fan=on in /boot/firmware/config.txt holds GPIO45; remove it and reboot"
    echo "      so svx_vehicle_detect.py can drive the fan."
fi
if rpicam-hello --list-cameras 2>/dev/null | grep -q imx219; then
    echo "PASS: IMX219 camera detected"
else
    echo "WARN: no IMX219 camera. Configure it first with SVX_PCM5_MIPI_Camera_Test/02_config_camera.sh"
fi
echo
echo "Done. Next:  ./run.sh camera   -> open http://<pi-ip>:8000"
