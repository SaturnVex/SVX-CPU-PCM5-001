# Vehicle Detection & Classification (Edge AI) Test

**Package:** `SVX_PCM5_Vehicle_Classify` · **Board:** `SVX-CPU-PCM5-001` · **Module:** Raspberry Pi CM5 (tested with CM5 Lite 8 GB, SC1568) · **OS:** Raspberry Pi OS 64-bit

On-device Edge AI: YOLOX vehicle detection and MobileNetV2 type classification (sedan, SUV, bus, truck, motorcycle) on the live IMX219 camera image, with boxes and live counts in a PC browser and optional CSV logging.

## Hardware
- IMX219 camera on MIPI1, Ethernet to the PC network (Internet needed once to download the models)

## Quick start (on the board)
```bash
sudo bash 01_setup.sh                     # packages, virtual environment, AI models
./run.sh camera                           # then open http://<PI_IP>:8000/ on the PC
./run.sh camera --mode nano               # fastest detector model
```

The AI models (YOLOX Nano / Tiny / S, MobileNetV2) are downloaded unmodified from their official releases by `01_setup.sh`; they are not part of this package (see NOTICE.txt).

Full setup, connections and acceptance criteria: see the PDF test guide `SaturnVex_PCM5_Vehicle_Classify_Test_Guide_EN.pdf`.
Copy this folder to the board (for example with `scp -r`) and run the scripts there; the guide shows the complete Windows PowerShell commands.

## License

© 2026 SaturnVex™ · www.saturnvex.com · support@saturnvex.com

SaturnVex files are provided under the BSD-3-Clause license (`LICENSE.txt`). Third-party software keeps its own license; see `NOTICE.txt`.
