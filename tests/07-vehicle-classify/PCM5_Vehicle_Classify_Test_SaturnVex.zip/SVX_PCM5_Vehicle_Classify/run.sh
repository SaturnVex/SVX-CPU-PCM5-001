#!/usr/bin/env bash
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
# run.sh - start svx_vehicle_detect.py with the .venv Python (onnxruntime). Same options.
# Usage : ./run.sh camera [options]     ./run.sh image FILES [--out DIR]
DIR="$(dirname "$(readlink -f "$0")")"
PY="$DIR/.venv/bin/python3"
[ -x "$PY" ] || { echo "No .venv yet (run: sudo bash 01_setup.sh). Using system python3 (slower)."; PY=python3; }
exec "$PY" "$DIR/svx_vehicle_detect.py" "$@"
