# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_vehicle_core.py - vehicle detection + type classification for board SVX-CPU-PCM5-001.

Two stages on the CM5 CPU, run with onnxruntime when installed (several times faster),
otherwise with the OpenCV DNN module:
  1. Detector   : YOLOX (COCO) finds car / motorcycle / bus / truck boxes.
  2. Classifier : each car/truck box is cropped and classified into
                  sedan / suv / truck. Two classifier modes:
                    - "imagenet": MobileNetV2 (ImageNet-1k) with a class-group map (no training)
                    - custom ONNX model trained with train_car_type.py (best accuracy)
  Optional tracker: a vehicle keeps its type between frames, so the classifier runs
  only a few times per vehicle instead of on every frame.
Output classes: sedan, suv, bus, truck, motorcycle.

No camera code here, so this file also runs on a PC for offline tests.
Model files are downloaded by 01_setup.sh (see NOTICE.txt for their licenses).
"""
import os
import time

import cv2
import numpy as np

try:
    import onnxruntime as ort
except ImportError:
    ort = None

CLASSES = ("sedan", "suv", "bus", "truck", "motorcycle")
COLORS = {  # BGR
    "sedan": (60, 200, 60), "suv": (0, 165, 255), "bus": (255, 120, 0),
    "truck": (40, 40, 220), "motorcycle": (220, 60, 220),
}

# COCO class id -> detector name (YOLOX COCO order)
COCO_VEHICLES = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}

DETECTOR_MODELS = {  # file, input size
    "nano": ("yolox_nano.onnx", 416),
    "tiny": ("yolox_tiny.onnx", 416),
    "s": ("yolox_s.onnx", 640),
}
IMAGENET_MODEL = "image_classification_mobilenetv2_2022apr.onnx"

# ImageNet-1k class index -> output group (used only in "imagenet" classifier mode)
IMAGENET_GROUPS = {
    "sedan": (436, 468, 511, 627, 661, 751, 817),   # beach wagon, cab, convertible, limousine,
                                                   # Model T, racer, sports car
    "suv": (609, 656, 734, 407),                    # jeep, minivan, police van, ambulance
    "truck": (717, 675, 867, 569, 555),             # pickup, moving van, trailer truck,
                                                   # garbage truck, fire engine
    "bus": (779, 874, 654),                         # school bus, trolleybus, minibus
}
# Decision thresholds for "imagenet" mode:
#   car box   -> truck if the truck group (pickup...) >= PICKUP_MIN, else sedan or suv
#   truck box -> suv   if sedan+suv groups >= CARLIKE_MIN (SUV/van seen as truck), else truck
PICKUP_MIN = 0.5
CARLIKE_MIN = 0.6

MEAN = np.array([0.485, 0.456, 0.406], np.float32)
STD = np.array([0.229, 0.224, 0.225], np.float32)


class Engine:
    """Runs one ONNX model: onnxruntime if available (engine auto/ort), else OpenCV DNN."""

    def __init__(self, path, threads=4, engine="auto"):
        if not os.path.isfile(path):
            raise FileNotFoundError(f"{path} not found. Run: sudo bash 01_setup.sh")
        if engine == "ort" and ort is None:
            raise FileNotFoundError("onnxruntime not installed. Run: sudo bash 01_setup.sh, "
                                    "then start the program with ./run.sh")
        self.use_ort = ort is not None and engine != "opencv"
        if self.use_ort:
            so = ort.SessionOptions()
            so.intra_op_num_threads = threads
            so.inter_op_num_threads = 1
            so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            self.sess = ort.InferenceSession(path, so, providers=["CPUExecutionProvider"])
            i = self.sess.get_inputs()[0]
            self.inp, self.batch = i.name, not isinstance(i.shape[0], int)
        else:
            cv2.setNumThreads(threads)
            self.net = cv2.dnn.readNet(path)
            self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
            self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
            self.batch = False            # batch > 1 fails for some models in OpenCV 4.10 DNN
        self.name = "onnxruntime" if self.use_ort else "OpenCV DNN"

    def run(self, blob):
        if self.use_ort:
            return self.sess.run(None, {self.inp: blob})[0]
        self.net.setInput(blob)
        return self.net.forward()


def _softmax(x):
    x = x - x.max(axis=1, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=1, keepdims=True)


class Detector:
    """YOLOX ONNX (exported without decode head), letterbox input, raw 0-255 BGR."""

    def __init__(self, model_dir, size="tiny", conf=0.35, nms=0.45, threads=4, engine="auto"):
        fname, self.inp = DETECTOR_MODELS[size]
        self.net = Engine(os.path.join(model_dir, fname), threads, engine)
        self.conf, self.nms = conf, nms
        grids, strides = [], []
        for s in (8, 16, 32):
            n = self.inp // s
            yv, xv = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
            grids.append(np.stack((xv, yv), 2).reshape(-1, 2))
            strides.append(np.full((n * n, 1), s))
        self.grid = np.concatenate(grids).astype(np.float32)
        self.stride = np.concatenate(strides).astype(np.float32)

    def __call__(self, bgr):
        h, w = bgr.shape[:2]
        r = min(self.inp / h, self.inp / w)
        canvas = np.full((self.inp, self.inp, 3), 114, np.uint8)
        canvas[:int(h * r), :int(w * r)] = cv2.resize(bgr, (int(w * r), int(h * r)),
                                                      interpolation=cv2.INTER_LINEAR)
        blob = canvas.transpose(2, 0, 1)[None].astype(np.float32)
        out = self.net.run(blob)[0]                         # (N, 85)

        xy = (out[:, :2] + self.grid) * self.stride
        wh = np.exp(out[:, 2:4]) * self.stride
        ids = list(COCO_VEHICLES)
        cls_scores = out[:, 5:][:, ids] * out[:, 4:5]       # vehicle classes only
        best = cls_scores.argmax(1)
        score = cls_scores[np.arange(len(best)), best]
        keep = score >= self.conf
        if not keep.any():
            return []
        xy, wh, score, best = xy[keep], wh[keep], score[keep], best[keep]
        boxes = np.concatenate((xy - wh / 2, wh), 1) / r    # x, y, w, h in source pixels
        # class-agnostic NMS: one box per vehicle even if car/truck both fire
        idx = cv2.dnn.NMSBoxes(boxes.tolist(), score.tolist(), self.conf, self.nms)
        dets = []
        for i in np.array(idx).reshape(-1):
            x, y, bw, bh = boxes[i]
            x1, y1 = max(0, int(x)), max(0, int(y))
            x2, y2 = min(w - 1, int(x + bw)), min(h - 1, int(y + bh))
            if x2 - x1 >= 4 and y2 - y1 >= 4:
                dets.append({"box": (x1, y1, x2, y2), "det": COCO_VEHICLES[ids[best[i]]],
                             "det_score": float(score[i])})
        return dets


def crop_square(bgr, box, margin=0.05, size=224):
    """Crop a box with a small margin, pad to square (keeps the body shape), resize."""
    h, w = bgr.shape[:2]
    x1, y1, x2, y2 = box
    mx, my = int((x2 - x1) * margin), int((y2 - y1) * margin)
    crop = bgr[max(0, y1 - my):min(h, y2 + my), max(0, x1 - mx):min(w, x2 + mx)]
    ch, cw = crop.shape[:2]
    side = max(ch, cw)
    sq = np.full((side, side, 3), 114, np.uint8)
    sq[(side - ch) // 2:(side - ch) // 2 + ch, (side - cw) // 2:(side - cw) // 2 + cw] = crop
    return cv2.resize(sq, (size, size), interpolation=cv2.INTER_AREA)


def to_blob(squares):
    rgb = np.stack([cv2.cvtColor(s, cv2.COLOR_BGR2RGB) for s in squares]).astype(np.float32)
    return ((rgb / 255.0 - MEAN) / STD).transpose(0, 3, 1, 2).astype(np.float32).copy()


class TypeClassifier:
    """Car/truck box -> sedan / suv / truck (/ bus)."""

    def __init__(self, model_dir, custom=None, threads=4, engine="auto"):
        if custom:
            self.net = Engine(custom, threads, engine)
            lbl = os.path.splitext(custom)[0] + ".labels.txt"
            with open(lbl, encoding="utf-8") as f:
                self.labels = [x.strip() for x in f if x.strip()]
            bad = [x for x in self.labels if x not in CLASSES]
            if bad:
                raise ValueError(f"{lbl}: unknown labels {bad}, allowed {CLASSES}")
            self.mode = "custom"
        else:
            self.net = Engine(os.path.join(model_dir, IMAGENET_MODEL), threads, engine)
            self.mode = "imagenet"

    def __call__(self, squares, det_names):
        """squares: list of 224x224 BGR crops. Returns list of (label, confidence)."""
        if not squares:
            return []
        if self.net.batch:            # all crops in one call
            raw = self.net.run(to_blob(squares)).reshape(len(squares), -1)
        else:
            raw = np.stack([self.net.run(to_blob([sq])).reshape(-1) for sq in squares])
        prob = _softmax(raw)
        res = []
        for p, det in zip(prob, det_names):
            if self.mode == "custom":
                k = int(p.argmax())
                res.append((self.labels[k], float(p[k])))
                continue
            g = {k: float(p[list(v)].sum()) for k, v in IMAGENET_GROUPS.items()}
            car = g["sedan"] + g["suv"]
            if det == "truck":
                res.append(("suv", car) if car >= CARLIKE_MIN else ("truck", 1.0 - car))
            elif g["truck"] >= PICKUP_MIN:
                res.append(("truck", g["truck"]))
            else:
                lab = "suv" if g["suv"] > g["sedan"] else "sedan"
                res.append((lab, g[lab] / car if car > 1e-6 else 0.0))
        return res


def iou(a, b):
    ix = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


class Tracker:
    """Greedy IoU tracker. Keeps each vehicle's type between frames (by votes) so the
    classifier only runs on new vehicles and a few times per vehicle."""

    def __init__(self, min_iou=0.3, max_miss=5):
        self.min_iou, self.max_miss = min_iou, max_miss
        self.tracks, self.next_id, self.frame = [], 1, 0

    def update(self, dets):
        self.frame += 1
        pairs = sorted(((iou(t["box"], d["box"]), ti, di) for ti, t in enumerate(self.tracks)
                        for di, d in enumerate(dets)), reverse=True)
        used_t, used_d = set(), set()
        for v, ti, di in pairs:
            if v < self.min_iou:
                break
            if ti in used_t or di in used_d:
                continue
            used_t.add(ti)
            used_d.add(di)
            t = self.tracks[ti]
            t["box"], t["miss"] = dets[di]["box"], 0
            dets[di]["track"] = t
        for ti, t in enumerate(self.tracks):
            if ti not in used_t:
                t["miss"] += 1
        self.tracks = [t for t in self.tracks if t["miss"] <= self.max_miss]
        for di, d in enumerate(dets):
            if di not in used_d:
                t = {"id": self.next_id, "box": d["box"], "votes": {}, "n_cls": 0,
                     "last_cls": -10 ** 9, "miss": 0}
                self.next_id += 1
                self.tracks.append(t)
                d["track"] = t


class VehiclePipeline:
    def __init__(self, model_dir, size="nano", conf=0.35, custom=None, threads=4,
                 engine="auto", track=False, reclass=10, max_votes=5):
        self.det = Detector(model_dir, size, conf, threads=threads, engine=engine)
        self.cls = TypeClassifier(model_dir, custom, threads, engine)
        self.tracker = Tracker() if track else None
        self.reclass, self.max_votes = reclass, max_votes
        self.engine = self.det.net.name
        self.t_det = self.t_cls = 0.0
        self.n_cls = 0                       # crops classified in the last call

    def __call__(self, bgr):
        """Returns list of dict: box, label, det, det_score, type_conf, (square: 224 crop)."""
        t0 = time.perf_counter()
        dets = self.det(bgr)
        t1 = time.perf_counter()
        if self.cls.mode == "custom":   # truck/bus boxes go to the model only if it knows them
            todo = [d for d in dets if d["det"] == "car"
                    or (d["det"] in ("truck", "bus") and d["det"] in self.cls.labels)]
        else:
            todo = [d for d in dets if d["det"] in ("car", "truck")]
        for d in dets:
            d["label"] = d["det"]               # bus / motorcycle kept as is
        if self.tracker:
            self.tracker.update(dets)
            frame = self.tracker.frame
            need = [d for d in todo if d["track"]["n_cls"] < self.max_votes
                    and frame - d["track"]["last_cls"] >= self.reclass]
        else:
            need = todo
        if need:
            squares = [crop_square(bgr, d["box"]) for d in need]
            for d, sq, (lab, c) in zip(need, squares, self.cls(squares, [d["det"] for d in need])):
                d["label"], d["type_conf"], d["square"] = lab, c, sq
                if self.tracker:
                    t = d["track"]
                    t["votes"][lab] = t["votes"].get(lab, 0.0) + max(c, 0.01)
                    t["n_cls"] += 1
                    t["last_cls"] = self.tracker.frame
        if self.tracker:                       # final type = vote winner of the track
            for d in todo:
                v = d["track"]["votes"]
                if v:
                    d["label"] = max(v, key=v.get)
                    d["type_conf"] = v[d["label"]] / sum(v.values())
        for d in dets:
            if d["label"] == "car":            # safety net, should not happen
                d["label"] = "sedan"
        self.n_cls = len(need)
        self.t_det, self.t_cls = t1 - t0, time.perf_counter() - t1
        return dets


def count(dets):
    c = {k: 0 for k in CLASSES}
    for d in dets:
        c[d["label"]] += 1
    return c


def draw(bgr, dets, info=""):
    for d in dets:
        x1, y1, x2, y2 = d["box"]
        col = COLORS[d["label"]]
        cv2.rectangle(bgr, (x1, y1), (x2, y2), col, 2)
        txt = f"{d['label']} {d['det_score']:.2f}"
        (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        ty = max(th + 4, y1)
        cv2.rectangle(bgr, (x1, ty - th - 4), (x1 + tw + 4, ty), col, -1)
        cv2.putText(bgr, txt, (x1 + 2, ty - 3), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (255, 255, 255), 1, cv2.LINE_AA)
    c = count(dets)
    line = "  ".join(f"{k}:{v}" for k, v in c.items())
    if info:
        line = f"{info}  |  {line}"
    cv2.rectangle(bgr, (0, 0), (bgr.shape[1], 24), (0, 0, 0), -1)
    cv2.putText(bgr, line, (6, 17), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    return bgr
