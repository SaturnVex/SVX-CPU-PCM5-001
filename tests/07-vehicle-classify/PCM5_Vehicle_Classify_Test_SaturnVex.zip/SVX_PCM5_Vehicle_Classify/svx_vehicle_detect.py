#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
svx_vehicle_detect.py - detect and classify vehicles (sedan, suv, bus, truck, motorcycle)
with the IMX219 camera on board SVX-CPU-PCM5-001.

  ./run.sh camera                       # live, view at http://<pi-ip>:8000
  ./run.sh camera --csv log.csv         # also log every detection
  ./run.sh camera --save-crops crops    # collect car crops for training
  ./run.sh image a.jpg dir/ --out result   # offline test on files
(run.sh = python3 of the local .venv with onnxruntime; plain python3 also works, slower)

Common options:
  --model nano|tiny|s   detector size (default nano = fastest; s = most accurate, slowest)
  --conf 0.35           detection threshold
  --custom FILE.onnx    car-type model from train_car_type.py (default: built-in ImageNet map)
  --engine auto|ort|opencv   inference engine (auto = onnxruntime if installed)

Fan (camera mode): CPU temperature controls the fan on RP1 GPIO45 (CM5 CN1 pin 19 Fan_PWM),
ON above 40 C, OFF below 35 C, active-low (GPIO LOW = fan ON, same as SVX_PCM5_Fan_Control).
  --fan-on 40 --fan-off 35 --fan-gpio 45 --fan-active-high --fan-exit on|off --no-fan
If the svx-fan service already drives GPIO45, this program leaves the fan to it.
"""
import argparse
import csv
import glob
import json
import os
import signal
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import cv2

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import svx_vehicle_core as V  # noqa: E402

PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SVX-CPU-PCM5-001 Vehicle Classify</title>
<style>body{font-family:sans-serif;background:#111;color:#eee;margin:0;padding:12px}
img{max-width:100%;height:auto;border:1px solid #444}table{border-collapse:collapse;margin-top:8px}
td{padding:2px 12px;border-bottom:1px solid #333}</style></head><body>
<h3>SVX-CPU-PCM5-001 &ndash; vehicle detection</h3><img src="/video"><table id="t"></table>
<script>
async function upd(){try{const s=await (await fetch('/stats')).json();
let h=`<tr><td>FPS</td><td>${s.fps.toFixed(1)}</td></tr><tr><td>Detector / classifier</td><td>${s.det_ms} / ${s.cls_ms} ms</td></tr>`;
h+=`<tr><td>CPU temp / clock / fan</td><td>${s.temp==null?'-':s.temp.toFixed(1)+' C'} / ${s.mhz==null?'-':s.mhz+' MHz'} / ${s.fan}</td></tr>`;
for(const [k,v] of Object.entries(s.now))h+=`<tr><td>${k} (now / max)</td><td>${v} / ${s.max[k]}</td></tr>`;
document.getElementById('t').innerHTML=h;}catch(e){}}
setInterval(upd,1000);upd();
</script></body></html>"""


class Shared:
    """Latest JPEG frame + statistics, shared between the camera loop and HTTP clients."""

    def __init__(self):
        self.cond = threading.Condition()
        self.jpeg, self.seq = None, 0
        self.stats = {"fps": 0.0, "det_ms": 0, "cls_ms": 0, "temp": None, "mhz": None, "fan": "-",
                      "now": {k: 0 for k in V.CLASSES}, "max": {k: 0 for k in V.CLASSES}}

    def put(self, jpeg, stats):
        with self.cond:
            self.jpeg, self.stats = jpeg, stats
            self.seq += 1
            self.cond.notify_all()


def make_handler(shared):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = PAGE.encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/stats":
                with shared.cond:
                    body = json.dumps(shared.stats).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/video":
                self.send_response(200)
                self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=FRAME")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                last = -1
                try:
                    while True:
                        with shared.cond:
                            shared.cond.wait_for(lambda: shared.seq != last, timeout=5)
                            jpeg, last = shared.jpeg, shared.seq
                        if jpeg is None:
                            continue
                        self.wfile.write(b"--FRAME\r\nContent-Type: image/jpeg\r\n"
                                         + f"Content-Length: {len(jpeg)}\r\n\r\n".encode()
                                         + jpeg + b"\r\n")
                except (BrokenPipeError, ConnectionResetError):
                    pass
            else:
                self.send_error(404)
    return H


def build_pipeline(a, track=False):
    model_dir = os.path.join(HERE, "models")
    p = V.VehiclePipeline(model_dir, a.model, a.conf, a.custom, a.threads, a.engine,
                          track=track, reclass=getattr(a, "reclass", 10))
    print(f"Engine {p.engine}, detector YOLOX-{a.model}, classifier: "
          f"{'custom ' + a.custom if a.custom else 'ImageNet map (no training)'}")
    if p.engine != "onnxruntime":
        print("TIP: onnxruntime is several times faster. Run sudo bash 01_setup.sh, then ./run.sh")
    return p


def run_images(a):
    pipe = build_pipeline(a)
    files = []
    for x in a.inputs:
        if os.path.isdir(x):
            for ext in ("jpg", "jpeg", "png", "bmp"):
                files += glob.glob(os.path.join(x, f"*.{ext}"))
        else:
            files.append(x)
    os.makedirs(a.out, exist_ok=True)
    for f in sorted(files):
        img = cv2.imread(f)
        if img is None:
            print(f"skip {f} (cannot read)")
            continue
        dets = pipe(img)
        out = os.path.join(a.out, os.path.splitext(os.path.basename(f))[0] + "_det.jpg")
        cv2.imwrite(out, V.draw(img, dets))
        c = V.count(dets)
        print(f"{os.path.basename(f)}: " + ", ".join(f"{k}={v}" for k, v in c.items())
              + f"  ({(pipe.t_det + pipe.t_cls) * 1000:.0f} ms) -> {out}")


def open_camera(a):
    try:
        from picamera2 import Picamera2
        from libcamera import Transform
    except ImportError:
        sys.exit("picamera2 not found. Run: sudo bash 01_setup.sh")
    cams = Picamera2.global_camera_info()
    if not cams:
        sys.exit("No camera detected. Check: rpicam-hello --list-cameras")
    if a.cam >= len(cams):
        sys.exit(f"Camera {a.cam} not found, available: 0..{len(cams) - 1}")
    cam = Picamera2(a.cam)
    cfg = cam.create_video_configuration(
        main={"size": (a.width, a.height), "format": "RGB888"},   # array is BGR for OpenCV
        transform=Transform(hflip=a.hflip, vflip=a.vflip), buffer_count=4)
    cam.configure(cfg)
    cam.start()
    time.sleep(1.0)                      # auto exposure settle
    return cam


TEMP_PATH = "/sys/class/thermal/thermal_zone0/temp"
FREQ_PATH = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"


def _read_int(path):
    try:
        with open(path) as f:
            return int(f.read().strip())
    except (OSError, ValueError):
        return None


class FanControl:
    """CPU temperature -> fan on one GPIO with hysteresis (same logic as SVX_PCM5_Fan_Control).
    Runs in its own thread; also reports temperature and CPU clock for the stats."""

    def __init__(self, a):
        self.gpio, self.on_c, self.off_c, self.interval = a.fan_gpio, a.fan_on, a.fan_off, 2.0
        self.active_low, self.exit_on = not a.fan_active_high, a.fan_exit == "on"
        self.req, self.on, self.temp, self.mhz = None, False, None, None
        self.chip, self.warned, self.v2 = None, False, True
        self.state = "disabled"
        self.lock = threading.Lock()
        self._read()
        if a.no_fan:
            return
        try:
            import gpiod
        except ImportError:
            self.state = "no libgpiod"
            print("FAN: python3-libgpiod not found (sudo apt install python3-libgpiod). "
                  "Fan not controlled.")
            return
        self.v2 = hasattr(gpiod, "request_lines")      # libgpiod v2 API, else v1 (1.6.x)
        chip = self._find_chip(gpiod)
        if chip is None:
            self.state = "no RP1 chip"
            print("FAN: RP1 GPIO chip not found (check: gpiodetect). Fan not controlled.")
            return
        # Same sequence as SVX_PCM5_Fan_Control (tested on the board): request the line with
        # the fan OFF, then switch it with set_value().
        try:
            if self.v2:
                from gpiod.line import Direction
                self.req = gpiod.request_lines(
                    chip, consumer="svx-vehicle-fan",
                    config={self.gpio: gpiod.LineSettings(direction=Direction.OUTPUT,
                                                          output_value=self._level(False))})
            else:
                self.chip = gpiod.Chip(chip)     # keep a reference: closing the chip frees the line
                line = self.chip.get_line(self.gpio)
                line.request(consumer="svx-vehicle-fan", type=gpiod.LINE_REQ_DIR_OUT,
                             default_val=self._level(False))
                self.req = line
        except OSError as e:
            self.state = "external"
            print(f"FAN: GPIO{self.gpio} busy ({e}). Another controller owns it (svx-fan service "
                  f"or dtparam=cooling_fan=on); fan left to it. Check: pinctrl get {self.gpio}")
            return
        self.on = self.temp is None or self.temp > self.on_c
        self._write(self.on)
        self.state = "ON" if self.on else "OFF"
        print(f"FAN: GPIO{self.gpio} on {chip} (libgpiod {'v2' if self.v2 else 'v1'}), "
              f"{'active-low' if self.active_low else 'active-high'}, ON > {self.on_c:g} C, "
              f"OFF < {self.off_c:g} C -> {self.state} at {self._t()}", flush=True)
        self._check()

    def _find_chip(self, gpiod):
        """Path of the RP1 GPIO chip (label 'pinctrl-rp1')."""
        for path in sorted(glob.glob("/dev/gpiochip*")):
            try:
                chip = gpiod.Chip(path)
                try:
                    if self.v2:
                        info = chip.get_info()
                        label, n = info.label, info.num_lines
                    else:
                        label, n = chip.label(), chip.num_lines()
                finally:
                    chip.close()
                if "rp1" in label and n > self.gpio:
                    return path
            except OSError:
                continue
        return None

    def _level(self, on):
        high = on != self.active_low
        if self.v2:
            from gpiod.line import Value
            return Value.ACTIVE if high else Value.INACTIVE
        return 1 if high else 0

    def _write(self, on):
        if self.v2:
            self.req.set_value(self.gpio, self._level(on))
        else:
            self.req.set_value(self._level(on))

    def _check(self):
        """Read the pin back; warn once if it is not at the level we drive."""
        try:
            got = (self.req.get_value(self.gpio) if self.v2 else self.req.get_value())
        except OSError:
            return
        if got != self._level(self.on) and not self.warned:
            self.warned = True
            print(f"FAN: WARNING GPIO{self.gpio} reads {got}, expected {self._level(self.on)}. "
                  f"Check: pinctrl get {self.gpio}", flush=True)

    def _t(self):
        return "?" if self.temp is None else f"{self.temp:.1f} C"

    def _read(self):
        t, f = _read_int(TEMP_PATH), _read_int(FREQ_PATH)
        self.temp = None if t is None else t / 1000.0
        self.mhz = None if not f else f // 1000

    def step(self):
        self._read()
        with self.lock:
            if self.req is None:
                return
            if self.temp is None:                       # cannot read -> fail-safe ON
                new = True
            else:
                new = True if self.temp > self.on_c else False if self.temp < self.off_c else self.on
            changed = new != self.on
            self.on = new
            self._write(new)                            # re-applied every check (idempotent)
            self.state = "ON" if new else "OFF"
            if changed:
                print(f"FAN {self.state} at {self._t()}", flush=True)
            self._check()

    def loop(self, stop):
        """Thread 4: check the temperature every 2 s."""
        while not stop.wait(self.interval):
            try:
                self.step()
            except OSError as e:
                print(f"FAN: error {e}", flush=True)

    def close(self):
        with self.lock:
            if self.req is None:
                return
            try:
                self._write(self.exit_on)
                print(f"Fan left {'ON' if self.exit_on else 'OFF'}.")
            finally:
                self.req.release()
                self.req = None
                if self.chip is not None:
                    self.chip.close()
                    self.chip = None


def _sigterm(*_):
    raise KeyboardInterrupt          # "kill" / systemd stop -> same clean exit as Ctrl+C


class Latest:
    """One-slot mailbox: the producer overwrites, the consumer always gets the newest item."""

    def __init__(self):
        self.cond = threading.Condition()
        self.item, self.seq = None, 0

    def put(self, item):
        with self.cond:
            self.item = item
            self.seq += 1
            self.cond.notify_all()

    def get(self, last, timeout=2.0):
        with self.cond:
            self.cond.wait_for(lambda: self.seq != last, timeout=timeout)
            return self.item, self.seq


def capture_loop(cam, out, stop):
    """Thread 1: camera -> newest frame (the camera never waits for the AI)."""
    while not stop.is_set():
        out.put(cam.capture_array("main"))


def encode_loop(inp, shared, stop):
    """Thread 3: draw boxes + JPEG encode for the web page (in parallel with the AI)."""
    last = 0
    while not stop.is_set():
        item, last = inp.get(last, 0.5)
        if item is None:
            continue
        bgr, dets, info, stats = item
        ok, jpg = cv2.imencode(".jpg", V.draw(bgr, dets, info), [cv2.IMWRITE_JPEG_QUALITY, 75])
        if ok:
            shared.put(jpg.tobytes(), stats)


def run_camera(a):
    signal.signal(signal.SIGTERM, _sigterm)
    fan = FanControl(a)                 # first, so the fan also runs while the models load
    fan_stop = threading.Event()
    fan_thread = threading.Thread(target=fan.loop, args=(fan_stop,), daemon=True)
    fan_thread.start()
    try:
        camera_loop(a, fan)
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        fan_stop.set()
        fan_thread.join(timeout=1.0)
        fan.close()


def camera_loop(a, fan):
    pipe = build_pipeline(a, track=not a.no_track)
    cam = open_camera(a)
    shared = Shared()
    stop = threading.Event()
    frames, to_web = Latest(), Latest()
    threading.Thread(target=capture_loop, args=(cam, frames, stop), daemon=True).start()
    if not a.no_web:
        threading.Thread(target=encode_loop, args=(to_web, shared, stop), daemon=True).start()
        srv = ThreadingHTTPServer(("0.0.0.0", a.port), make_handler(shared))
        srv.daemon_threads = True
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        print(f"Open http://<pi-ip>:{a.port}  (Ctrl+C to stop)")

    log = writer = None
    if a.csv:
        new = not os.path.exists(a.csv)
        log = open(a.csv, "a", newline="")
        writer = csv.writer(log)
        if new:
            writer.writerow(["time", "frame", "track_id", "label", "det_score", "type_conf",
                             "x1", "y1", "x2", "y2"])
    crops_saved = 0

    peak = {k: 0 for k in V.CLASSES}
    frame, t_fps, n_fps, fps, t_print, last = 0, time.time(), 0, 0.0, 0.0, 0
    try:
        while True:                                   # Thread 2 (main): AI on the newest frame
            bgr, last = frames.get(last)
            if bgr is None:
                continue
            dets = pipe(bgr)
            frame += 1
            now = time.time()
            c = V.count(dets)
            for k in peak:
                peak[k] = max(peak[k], c[k])

            if writer:
                ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now))
                for d in dets:
                    tid = d["track"]["id"] if "track" in d else ""
                    writer.writerow([ts, frame, tid, d["label"], f"{d['det_score']:.2f}",
                                     f"{d.get('type_conf', 0):.2f}", *d["box"]])
            if a.save_crops and crops_saved < a.crop_max:
                for i, d in enumerate(dets):           # with tracking: max 5 crops per vehicle
                    if "square" in d and crops_saved < a.crop_max:
                        sub = os.path.join(a.save_crops, d["label"])   # first guess, sort by hand
                        os.makedirs(sub, exist_ok=True)
                        cv2.imwrite(os.path.join(sub, f"{int(now)}_{frame}_{i}.jpg"), d["square"])
                        crops_saved += 1

            n_fps += 1
            if now - t_fps >= 1.0:
                fps, n_fps, t_fps = n_fps / (now - t_fps), 0, now
            if not a.no_web:
                to_web.put((bgr, [{k: d[k] for k in ("box", "label", "det_score")} for d in dets],
                            f"{fps:.1f} fps",
                            {"fps": fps, "det_ms": round(pipe.t_det * 1000),
                             "cls_ms": round(pipe.t_cls * 1000), "temp": fan.temp,
                             "mhz": fan.mhz, "fan": fan.state, "now": c, "max": dict(peak)}))
            if now - t_print >= 2.0:
                t_print = now
                if log:
                    log.flush()
                extra = f"  crops={crops_saved}" if a.save_crops else ""
                extra += (f"  | {'-' if fan.temp is None else f'{fan.temp:.1f}'}C"
                          f" {fan.mhz or '-'}MHz fan {fan.state}")
                print(f"{fps:4.1f} fps  det {pipe.t_det * 1000:3.0f} ms  cls {pipe.t_cls * 1000:3.0f} ms  "
                      + "  ".join(f"{k}={v}" for k, v in c.items()) + extra, flush=True)
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        stop.set()
        time.sleep(0.2)
        cam.stop()
        if log:
            log.close()


def main():
    p = argparse.ArgumentParser(description="SVX-CPU-PCM5-001 vehicle detection / classification")
    sub = p.add_subparsers(dest="mode", required=True)

    def common(sp):
        sp.add_argument("--model", choices=list(V.DETECTOR_MODELS), default="nano")
        sp.add_argument("--conf", type=float, default=0.35)
        sp.add_argument("--custom", help="car-type ONNX from train_car_type.py")
        sp.add_argument("--threads", type=int, default=4)
        sp.add_argument("--engine", choices=["auto", "ort", "opencv"], default="auto",
                        help="auto = onnxruntime if installed, else OpenCV DNN")

    c = sub.add_parser("camera", help="live camera")
    common(c)
    c.add_argument("--cam", type=int, default=0, help="0 = first detected camera (MIPI1 if only one)")
    c.add_argument("--width", type=int, default=1280)
    c.add_argument("--height", type=int, default=720)
    c.add_argument("--hflip", action="store_true")
    c.add_argument("--vflip", action="store_true")
    c.add_argument("--port", type=int, default=8000)
    c.add_argument("--no-web", action="store_true", help="console only")
    c.add_argument("--csv", help="append every detection to this CSV file")
    c.add_argument("--save-crops", metavar="DIR", help="save car/truck crops for training")
    c.add_argument("--crop-max", type=int, default=3000)
    c.add_argument("--reclass", type=int, default=10,
                   help="re-check a vehicle's type every N frames (max 5 times)")
    c.add_argument("--no-track", action="store_true", help="classify every vehicle on every frame")
    c.add_argument("--fan-gpio", type=int, default=45, help="fan GPIO (45 = CM5 CN1 pin 19 Fan_PWM)")
    c.add_argument("--fan-on", type=float, default=40.0, help="fan ON above this CPU temp, C")
    c.add_argument("--fan-off", type=float, default=35.0, help="fan OFF below this CPU temp, C")
    c.add_argument("--fan-active-high", action="store_true",
                   help="GPIO HIGH = fan ON (default active-low: GPIO45 LOW = fan ON)")
    c.add_argument("--fan-exit", choices=["on", "off"], default="on",
                   help="fan state when the program stops (default on, fail-safe)")
    c.add_argument("--no-fan", action="store_true", help="do not control the fan")

    i = sub.add_parser("image", help="run on image files or folders")
    common(i)
    i.add_argument("inputs", nargs="+")
    i.add_argument("--out", default="result")

    a = p.parse_args()
    if a.custom and not os.path.isfile(a.custom):
        sys.exit(f"{a.custom} not found")
    if a.mode == "camera" and a.fan_off >= a.fan_on:
        sys.exit(f"--fan-off ({a.fan_off}) must be lower than --fan-on ({a.fan_on})")
    try:
        run_camera(a) if a.mode == "camera" else run_images(a)
    except FileNotFoundError as e:
        sys.exit(str(e))


if __name__ == "__main__":
    main()
