#!/usr/bin/env python3
# SPDX-License-Identifier: BSD-3-Clause
# Copyright (c) 2026 Tuyen Nguyen (SaturnVex)
"""
train_car_type.py - train the car-type classifier used by svx_vehicle_detect.py --custom.
Run on a PC (Windows/Linux, CPU is enough; a GPU is used automatically if present).

Dataset: one sub-folder per class, names taken from: sedan, suv, truck, bus, motorcycle
  dataset/sedan/*.jpg   dataset/suv/*.jpg   dataset/truck/*.jpg   (at least 2 classes)
Best source: crops collected on the board with
  python3 svx_vehicle_detect.py camera --save-crops crops
then moved into the correct folder by hand (the folder names are only a first guess).

  pip install torch torchvision onnx
  python train_car_type.py dataset --epochs 15 --out car_type.onnx
Output: car_type.onnx + car_type.labels.txt -> copy both to the board's models/ folder.

Uses the torchvision MobileNetV3-Small ImageNet weights (BSD-3-Clause) as a starting point.
"""
import argparse
import os
import random
import sys

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, Subset
    from torchvision import datasets, models, transforms
    import torchvision.transforms.functional as TF
except ImportError:
    sys.exit("Install first: pip install torch torchvision onnx")

ALLOWED = ("sedan", "suv", "bus", "truck", "motorcycle")
MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


class PadSquare:
    """Same as crop_square() on the board: pad to a square with grey 114, keep aspect ratio."""

    def __call__(self, img):
        w, h = img.size
        s = max(w, h)
        left, top = (s - w) // 2, (s - h) // 2
        return TF.pad(img, [left, top, s - w - left, s - h - top], fill=(114, 114, 114))


def loaders(root, batch, val_split, seed):
    train_tf = transforms.Compose([
        PadSquare(), transforms.Resize((224, 224)),
        transforms.RandomResizedCrop(224, scale=(0.80, 1.0), ratio=(0.9, 1.1)),
        transforms.RandomHorizontalFlip(),
        transforms.ColorJitter(0.3, 0.3, 0.3, 0.05),
        transforms.ToTensor(), transforms.Normalize(MEAN, STD)])
    val_tf = transforms.Compose([PadSquare(), transforms.Resize((224, 224)),
                                 transforms.ToTensor(), transforms.Normalize(MEAN, STD)])
    full_t = datasets.ImageFolder(root, train_tf)
    full_v = datasets.ImageFolder(root, val_tf)
    bad = [c for c in full_t.classes if c not in ALLOWED]
    if bad or len(full_t.classes) < 2:
        sys.exit(f"Class folders {full_t.classes}: need >= 2, allowed names {ALLOWED}")
    idx = list(range(len(full_t)))
    random.Random(seed).shuffle(idx)
    n_val = max(1, int(len(idx) * val_split))
    tr, va = Subset(full_t, idx[n_val:]), Subset(full_v, idx[:n_val])
    counts = [0] * len(full_t.classes)
    for i in idx[n_val:]:
        counts[full_t.targets[i]] += 1
    print("classes:", dict(zip(full_t.classes, counts)), f"(train), {n_val} val images")
    return (DataLoader(tr, batch, shuffle=True, num_workers=0),
            DataLoader(va, batch, shuffle=False, num_workers=0), full_t.classes, counts)


def evaluate(model, dl, n_cls, dev):
    model.eval()
    cm = [[0] * n_cls for _ in range(n_cls)]
    with torch.no_grad():
        for x, y in dl:
            pred = model(x.to(dev)).argmax(1).cpu()
            for t, p in zip(y.tolist(), pred.tolist()):
                cm[t][p] += 1
    correct = sum(cm[i][i] for i in range(n_cls))
    return correct / max(1, sum(map(sum, cm))), cm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dataset")
    ap.add_argument("--epochs", type=int, default=15)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--val", type=float, default=0.2, help="validation fraction")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default="car_type.onnx")
    a = ap.parse_args()

    torch.manual_seed(a.seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tr, va, classes, counts = loaders(a.dataset, a.batch, a.val, a.seed)

    model = models.mobilenet_v3_small(weights=models.MobileNet_V3_Small_Weights.IMAGENET1K_V1)
    model.classifier[3] = nn.Linear(model.classifier[3].in_features, len(classes))
    model.to(dev)
    w = torch.tensor([sum(counts) / (len(counts) * max(1, c)) for c in counts], dtype=torch.float32)
    loss_fn = nn.CrossEntropyLoss(weight=w.to(dev))          # balances unequal class sizes
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, a.epochs)

    best, best_state = -1.0, None
    for ep in range(1, a.epochs + 1):
        model.train()
        tot, n = 0.0, 0
        for x, y in tr:
            x, y = x.to(dev), y.to(dev)
            opt.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            opt.step()
            tot, n = tot + loss.item() * len(y), n + len(y)
        sched.step()
        acc, _ = evaluate(model, va, len(classes), dev)
        print(f"epoch {ep:2d}/{a.epochs}  loss {tot / max(1, n):.3f}  val acc {acc * 100:5.1f}%")
        if acc > best:
            best, best_state = acc, {k: v.detach().clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    acc, cm = evaluate(model, va, len(classes), dev)
    print(f"\nbest val acc {acc * 100:.1f}%  confusion (row = true, col = predicted):")
    print("          " + "".join(f"{c:>11}" for c in classes))
    for c, row in zip(classes, cm):
        print(f"{c:>10}" + "".join(f"{v:>11}" for v in row))

    model.cpu().eval()
    dummy = torch.zeros(1, 3, 224, 224)
    export_kw = dict(input_names=["input"], output_names=["output"],
                     dynamic_axes={"input": {0: "batch"}, "output": {0: "batch"}}, opset_version=13)
    try:     # classic exporter: opset 13 loads in OpenCV 4.x DNN on the board
        torch.onnx.export(model, dummy, a.out, dynamo=False, **export_kw)
    except TypeError:
        torch.onnx.export(model, dummy, a.out, **export_kw)
    lbl = os.path.splitext(a.out)[0] + ".labels.txt"
    with open(lbl, "w", encoding="utf-8") as f:
        f.write("\n".join(classes) + "\n")
    print(f"\nSaved {a.out} and {lbl}. Copy both to SVX_PCM5_Vehicle_Classify/models/ on the board.")


if __name__ == "__main__":
    main()
